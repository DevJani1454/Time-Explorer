from django.shortcuts import render, redirect, get_object_or_404
from django.http import JsonResponse
from django.contrib import messages
from django.conf import settings
from .models import HistoricalExploration, CommunityExploration
from .services import HistoricalExplorationService


def home(request):
    return render(request, 'vision/home.html')


def input_form(request):
    if request.method == 'POST':
        location = request.POST.get('location')
        time_period = request.POST.get('time_period')
        custom_year = request.POST.get('custom_year')
        content_type = request.POST.get('content_type', 'comprehensive')
        
        if location and time_period:
            # Initialize exploration service
            exploration_service = HistoricalExplorationService()
            
            # Generate comprehensive historical content
            content = exploration_service.generate_historical_content(
                location, time_period, custom_year, content_type
            )
            
            exploration = HistoricalExploration.objects.create(
                location=location,
                time_period=time_period,
                custom_year=custom_year,
                content_type=content_type,
                historical_narrative=content['narrative'],
                cultural_info=content['cultural_info'],
                architectural_details=content['architectural_details'],
                lifestyle_description=content['lifestyle_description'],
                historical_image_url=content['historical_image_url'],
                modern_comparison_url=content['modern_comparison_url'],
                cultural_artifact_url=content['cultural_artifact_url'],
                key_facts=content['key_facts'],
                notable_figures=content['notable_figures'],
                historical_events=content['historical_events']
            )
            
            messages.success(request, 'Historical exploration generated successfully with AI-powered content!')
            return redirect('vision:results', exploration_id=exploration.id)
        else:
            messages.error(request, 'Please fill in all required fields.')
    
    return render(request, 'vision/input.html')


def results(request, exploration_id):
    exploration = get_object_or_404(HistoricalExploration, id=exploration_id)
    return render(request, 'vision/results.html', {'exploration': exploration})


def about(request):
    return render(request, 'vision/about.html')


def community(request):
    explorations = CommunityExploration.objects.all()[:20]
    return render(request, 'vision/community.html', {'explorations': explorations})


def api_community_explorations(request):
    time_filter = request.GET.get('time_period', 'all')
    
    explorations = CommunityExploration.objects.all()
    if time_filter != 'all':
        explorations = explorations.filter(time_period__icontains=time_filter)
    
    data = []
    for exploration in explorations:
        data.append({
            'id': exploration.id,
            'title': exploration.title,
            'location': exploration.location,
            'time_period': exploration.time_period,
            'snippet': exploration.snippet,
            'image_url': exploration.image_url,
            'coordinates': [exploration.latitude, exploration.longitude],
            'timestamp': exploration.created_at.strftime('%Y-%m-%d %H:%M')
        })
    
    return JsonResponse({'explorations': data})