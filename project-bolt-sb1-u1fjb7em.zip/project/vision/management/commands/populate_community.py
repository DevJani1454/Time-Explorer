from django.core.management.base import BaseCommand
from vision.models import CommunityVision


class Command(BaseCommand):
    help = 'Populate community visions with sample data'

    def handle(self, *args, **options):
        sample_visions = [
            {
                'title': 'Neon Dreams of Ancient Spirits',
                'location': 'Tokyo, Japan',
                'ancestry': 'east_asian',
                'snippet': 'The electric dragons dance between glass towers, their light-breath warming the metal hearts of our steel ancestors...',
                'full_narrative': 'In this realm of endless light, I see the harmony of yin and yang manifest in towers that pierce the heavens. The electric dragons dance between glass towers, their light-breath warming the metal hearts of our steel ancestors. The ancient flow of qi now moves through cables of light, connecting souls across vast distances as our ancestors connected through the Silk Road. The same wisdom that guided our emperors now flows through glowing screens, and the eternal search for balance continues in this forest of glass and steel.',
                'image_url': 'https://images.pexels.com/photos/2506923/pexels-photo-2506923.jpeg?auto=compress&cs=tinysrgb&w=800',
                'latitude': 35.6762,
                'longitude': 139.6503
            },
            {
                'title': 'Where Odin\'s Ravens See Wifi Signals',
                'location': 'Reykjavik, Iceland',
                'ancestry': 'germanic_norse',
                'snippet': 'The invisible threads of Loki\'s web connect every soul in this realm of ice and fire...',
                'full_narrative': 'By Odin\'s ravens, what manner of Asgard is this? These metal and glass halls rise like the world-tree Yggdrasil, their branches touching the sky realm. The invisible threads of Loki\'s web connect every soul in this realm of ice and fire. The thunder that moves without storm, the light without flame - surely this is the work of the All-Father\'s magic. I witness the eternal struggle of mortals seeking their destiny, now played out on glowing screens instead of battlefields.',
                'image_url': 'https://images.pexels.com/photos/1287145/pexels-photo-1287145.jpeg?auto=compress&cs=tinysrgb&w=800',
                'latitude': 64.1466,
                'longitude': -21.9426
            },
            {
                'title': 'Pharaoh\'s Vision of the Digital Nile',
                'location': 'Cairo, Egypt',
                'ancestry': 'middle_eastern_persian',
                'snippet': 'The great river now flows with streams of light, carrying the prayers of millions across the eternal desert...',
                'full_narrative': 'By the light of Ahura Mazda, what wonders bloom in this land of the pharaohs! These towers rise like the minarets of a thousand mosques, calling the faithful not to prayer but to the eternal human quest for connection and meaning. The great river now flows with streams of light, carrying the prayers of millions across the eternal desert. The same fire that burned in our sacred temples now glows in countless screens, illuminating faces with the same wonder our ancestors felt gazing at the stars.',
                'image_url': 'https://images.pexels.com/photos/3889855/pexels-photo-3889855.jpeg?auto=compress&cs=tinysrgb&w=800',
                'latitude': 30.0444,
                'longitude': 31.2357
            },
            {
                'title': 'Jaguar Spirit in Concrete Jungle',
                'location': 'São Paulo, Brazil',
                'ancestry': 'indigenous_american',
                'snippet': 'The sacred jaguar prowls through canyons of stone, its spots reflecting the countless windows of modern caves...',
                'full_narrative': 'The concrete rivers run where once the great forests breathed, and the steel trees grow where our sacred ceiba stood. The sacred jaguar prowls through canyons of stone, its spots reflecting the countless windows of modern caves. Yet I sense the same spirit in the flowing crowds - the eternal dance of community, the seeking of sustenance, the honoring of journeys both long and short. The great spirit moves through fiber optic cables as it once moved through wind and water.',
                'image_url': 'https://images.pexels.com/photos/1670187/pexels-photo-1670187.jpeg?auto=compress&cs=tinysrgb&w=800',
                'latitude': -23.5505,
                'longitude': -46.6333
            },
            {
                'title': 'Banshee\'s Lament for Silicon Dreams',
                'location': 'Dublin, Ireland',
                'ancestry': 'celtic_irish',
                'snippet': 'The old songs echo through fiber optic harps, weaving tales of silicon fairies and digital druids...',
                'full_narrative': 'By the ancient stones of Tara, what manner of realm is this? These towering monuments of glass and steel reach toward the heavens like the sacred megaliths of our time, yet they pulse with an energy unknown to our druids. The old songs echo through fiber optic harps, weaving tales of silicon fairies and digital druids. The streams of light that flow through these structures carry the voices of a thousand souls, speaking in tongues we never knew existed.',
                'image_url': 'https://images.pexels.com/photos/2166711/pexels-photo-2166711.jpeg?auto=compress&cs=tinysrgb&w=800',
                'latitude': 53.3498,
                'longitude': -6.2603
            },
            {
                'title': 'Ganesha\'s Blessing on Digital Pathways',
                'location': 'Mumbai, India',
                'ancestry': 'south_asian',
                'snippet': 'The remover of obstacles now clears the paths of data streams, blessing each connection with ancient wisdom...',
                'full_narrative': 'In this realm where the sacred Ganges meets the digital ocean, I see Lord Ganesha\'s wisdom manifest in new forms. The remover of obstacles now clears the paths of data streams, blessing each connection with ancient wisdom. The same dharma that guided our ancestors through the cycles of existence now flows through networks of light, connecting souls in their eternal journey toward moksha. The lotus of enlightenment blooms in server farms as it once bloomed in temple ponds.',
                'image_url': 'https://images.pexels.com/photos/1007025/pexels-photo-1007025.jpeg?auto=compress&cs=tinysrgb&w=800',
                'latitude': 19.0760,
                'longitude': 72.8777
            }
        ]

        for vision_data in sample_visions:
            vision, created = CommunityVision.objects.get_or_create(
                title=vision_data['title'],
                defaults=vision_data
            )
            if created:
                self.stdout.write(
                    self.style.SUCCESS(f'Created vision: {vision.title}')
                )
            else:
                self.stdout.write(
                    self.style.WARNING(f'Vision already exists: {vision.title}')
                )

        self.stdout.write(
            self.style.SUCCESS('Successfully populated community visions!')
        )