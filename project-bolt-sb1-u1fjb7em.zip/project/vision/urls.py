from django.urls import path
from . import views

app_name = 'vision'

urlpatterns = [
    path('', views.home, name='home'),
    path('explore/', views.input_form, name='input'),
    path('results/<int:exploration_id>/', views.results, name='results'),
    path('about/', views.about, name='about'),
    path('community/', views.community, name='community'),
    path('api/community-explorations/', views.api_community_explorations, name='api_community_explorations'),
]