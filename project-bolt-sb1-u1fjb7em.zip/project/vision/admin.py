from django.contrib import admin
from .models import Vision, CommunityVision


@admin.register(Vision)
class VisionAdmin(admin.ModelAdmin):
    list_display = ['location', 'ancestry', 'display_mode', 'created_at']
    list_filter = ['ancestry', 'display_mode', 'created_at']
    search_fields = ['location', 'narrative']
    readonly_fields = ['created_at']


@admin.register(CommunityVision)
class CommunityVisionAdmin(admin.ModelAdmin):
    list_display = ['title', 'location', 'ancestry', 'created_at']
    list_filter = ['ancestry', 'created_at']
    search_fields = ['title', 'location', 'snippet']
    readonly_fields = ['created_at']