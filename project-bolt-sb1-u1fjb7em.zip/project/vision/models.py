from django.db import models
from django.utils import timezone


class HistoricalExploration(models.Model):
    TIME_PERIOD_CHOICES = [
        ('ancient', 'Ancient Times (Before 500 CE)'),
        ('medieval', 'Medieval Period (500-1500 CE)'),
        ('renaissance', 'Renaissance (1400-1600 CE)'),
        ('industrial', 'Industrial Revolution (1760-1840)'),
        ('modern_early', 'Early Modern (1900-1950)'),
        ('modern_late', 'Late Modern (1950-2000)'),
        ('contemporary', 'Contemporary (2000-Present)'),
        ('custom', 'Custom Time Period'),
    ]
    
    CONTENT_TYPE_CHOICES = [
        ('comprehensive', 'Complete Historical Package'),
        ('cultural_focus', 'Cultural & Social Focus'),
        ('architectural', 'Architecture & Buildings'),
        ('lifestyle', 'Daily Life & Customs'),
        ('events', 'Historical Events & Politics'),
    ]
    
    location = models.CharField(max_length=200)
    time_period = models.CharField(max_length=20, choices=TIME_PERIOD_CHOICES)
    custom_year = models.CharField(max_length=50, blank=True, null=True)
    content_type = models.CharField(max_length=20, choices=CONTENT_TYPE_CHOICES, default='comprehensive')
    
    # Generated content
    historical_narrative = models.TextField(blank=True)
    cultural_info = models.TextField(blank=True)
    architectural_details = models.TextField(blank=True)
    lifestyle_description = models.TextField(blank=True)
    
    # Media URLs
    historical_image_url = models.URLField(blank=True, null=True)
    modern_comparison_url = models.URLField(blank=True, null=True)
    cultural_artifact_url = models.URLField(blank=True, null=True)
    
    # Additional data
    key_facts = models.JSONField(default=list, blank=True)
    notable_figures = models.JSONField(default=list, blank=True)
    historical_events = models.JSONField(default=list, blank=True)
    
    created_at = models.DateTimeField(default=timezone.now)
    
    def __str__(self):
        period_display = self.custom_year if self.time_period == 'custom' else self.get_time_period_display()
        return f"{self.location} in {period_display}"
    
    class Meta:
        ordering = ['-created_at']


class CommunityExploration(models.Model):
    title = models.CharField(max_length=200)
    location = models.CharField(max_length=200)
    time_period = models.CharField(max_length=100)
    snippet = models.TextField()
    full_description = models.TextField()
    image_url = models.URLField(blank=True, null=True)
    latitude = models.FloatField(default=0.0)
    longitude = models.FloatField(default=0.0)
    created_at = models.DateTimeField(default=timezone.now)
    
    def __str__(self):
        return self.title
    
    class Meta:
        ordering = ['-created_at']