import openai
import base64
import os
import json
from django.conf import settings
from django.core.files.base import ContentFile
from django.core.files.storage import default_storage
import uuid


class HistoricalExplorationService:
    def __init__(self):
        self.client = openai.OpenAI(
            api_key=os.getenv('OPENAI_API_KEY', 'your-openai-api-key-here')
        )
    
    def generate_historical_content(self, location, time_period, custom_year=None, content_type='comprehensive'):
        """Generate comprehensive historical content for a location and time period"""
        
        # Determine the actual time period
        period_text = custom_year if time_period == 'custom' else self._get_period_description(time_period)
        
        # Generate narrative content
        narrative = self._generate_historical_narrative(location, period_text, content_type)
        
        # Generate cultural information
        cultural_info = self._generate_cultural_information(location, period_text)
        
        # Generate architectural details
        architectural_details = self._generate_architectural_details(location, period_text)
        
        # Generate lifestyle description
        lifestyle_description = self._generate_lifestyle_description(location, period_text)
        
        # Generate key facts, figures, and events
        additional_data = self._generate_additional_data(location, period_text)
        
        # Generate images
        historical_image = self._generate_historical_image(location, period_text)
        modern_comparison = self._generate_modern_comparison_image(location)
        cultural_artifact = self._generate_cultural_artifact_image(location, period_text)
        
        return {
            'narrative': narrative,
            'cultural_info': cultural_info,
            'architectural_details': architectural_details,
            'lifestyle_description': lifestyle_description,
            'historical_image_url': historical_image,
            'modern_comparison_url': modern_comparison,
            'cultural_artifact_url': cultural_artifact,
            'key_facts': additional_data.get('key_facts', []),
            'notable_figures': additional_data.get('notable_figures', []),
            'historical_events': additional_data.get('historical_events', [])
        }
    
    def _generate_historical_narrative(self, location, period, content_type):
        """Generate historical narrative using OpenAI"""
        prompt = f"""Write a comprehensive historical narrative about {location} during {period}. 
        Focus on {content_type}. Include:
        - What the area looked like and felt like during this time
        - Major cultural and social aspects
        - Important historical context
        - Daily life of people living there
        - Significant events or changes happening
        
        Write in an engaging, informative style that brings the past to life."""
        
        try:
            response = self.client.chat.completions.create(
                model="gpt-4o",
                messages=[{"role": "user", "content": prompt}],
                max_tokens=1000,
                temperature=0.7
            )
            return response.choices[0].message.content
        except Exception as e:
            print(f"Error generating narrative: {e}")
            return f"Historical information about {location} during {period} is being researched. Please try again later."
    
    def _generate_cultural_information(self, location, period):
        """Generate cultural information"""
        prompt = f"""Provide detailed cultural information about {location} during {period}. Include:
        - Religious practices and beliefs
        - Art, music, and literature
        - Social customs and traditions
        - Food and cuisine
        - Clothing and fashion
        - Festivals and celebrations
        
        Be specific and historically accurate."""
        
        try:
            response = self.client.chat.completions.create(
                model="gpt-4o",
                messages=[{"role": "user", "content": prompt}],
                max_tokens=800,
                temperature=0.7
            )
            return response.choices[0].message.content
        except Exception as e:
            print(f"Error generating cultural info: {e}")
            return "Cultural information is being compiled..."
    
    def _generate_architectural_details(self, location, period):
        """Generate architectural information"""
        prompt = f"""Describe the architecture and buildings of {location} during {period}. Include:
        - Typical building styles and materials
        - Notable structures or monuments
        - Urban planning and city layout
        - Construction techniques
        - Architectural influences
        - How buildings reflected the culture and society
        
        Be detailed and historically accurate."""
        
        try:
            response = self.client.chat.completions.create(
                model="gpt-4o",
                messages=[{"role": "user", "content": prompt}],
                max_tokens=800,
                temperature=0.7
            )
            return response.choices[0].message.content
        except Exception as e:
            print(f"Error generating architectural details: {e}")
            return "Architectural information is being compiled..."
    
    def _generate_lifestyle_description(self, location, period):
        """Generate lifestyle and daily life information"""
        prompt = f"""Describe daily life and lifestyle in {location} during {period}. Include:
        - How people lived day-to-day
        - Work and occupations
        - Family life and social structure
        - Education and learning
        - Entertainment and leisure
        - Transportation and communication
        - Economic activities
        
        Paint a vivid picture of what life was really like."""
        
        try:
            response = self.client.chat.completions.create(
                model="gpt-4o",
                messages=[{"role": "user", "content": prompt}],
                max_tokens=800,
                temperature=0.7
            )
            return response.choices[0].message.content
        except Exception as e:
            print(f"Error generating lifestyle description: {e}")
            return "Lifestyle information is being compiled..."
    
    def _generate_additional_data(self, location, period):
        """Generate key facts, notable figures, and historical events"""
        prompt = f"""Provide structured information about {location} during {period} in JSON format:
        {{
            "key_facts": ["fact1", "fact2", "fact3", "fact4", "fact5"],
            "notable_figures": [
                {{"name": "Person Name", "role": "Their role/significance", "years": "Active years"}},
                {{"name": "Person Name", "role": "Their role/significance", "years": "Active years"}}
            ],
            "historical_events": [
                {{"event": "Event name", "year": "Year", "significance": "Why it was important"}},
                {{"event": "Event name", "year": "Year", "significance": "Why it was important"}}
            ]
        }}
        
        Provide accurate historical information."""
        
        try:
            response = self.client.chat.completions.create(
                model="gpt-4o",
                messages=[{"role": "user", "content": prompt}],
                max_tokens=1000,
                temperature=0.7
            )
            return json.loads(response.choices[0].message.content)
        except Exception as e:
            print(f"Error generating additional data: {e}")
            return {
                "key_facts": ["Historical data is being compiled..."],
                "notable_figures": [],
                "historical_events": []
            }
    
    def _generate_historical_image(self, location, period):
        """Generate historical visualization image"""
        prompt = f"Draw a detailed historical visualization of {location} during {period}. Show the architecture, people in period clothing, daily activities, and the overall atmosphere of the time. Historically accurate, detailed, artistic style."
        
        try:
            response = self.client.responses.create(
                model="gpt-4o",
                input=prompt,
                tools=[{
                    "type": "image_generation",
                    "size": "1024x1024",
                    "quality": "high",
                    "format": "png"
                }]
            )
            
            image_data = [
                output.result
                for output in response.output
                if output.type == "image_generation_call"
            ]
            
            if image_data:
                return self._save_base64_image(image_data[0], f"historical_{location}_{period}_{uuid.uuid4().hex[:8]}")
                
        except Exception as e:
            print(f"Error generating historical image: {e}")
        
        return 'https://images.pexels.com/photos/1670187/pexels-photo-1670187.jpeg?auto=compress&cs=tinysrgb&w=800'
    
    def _generate_modern_comparison_image(self, location):
        """Generate modern comparison image"""
        prompt = f"Draw a modern photograph of {location} showing contemporary architecture, streets, and urban life. Realistic, high-quality, daytime lighting."
        
        try:
            response = self.client.responses.create(
                model="gpt-4o",
                input=prompt,
                tools=[{
                    "type": "image_generation",
                    "size": "1024x1024",
                    "quality": "high",
                    "format": "png"
                }]
            )
            
            image_data = [
                output.result
                for output in response.output
                if output.type == "image_generation_call"
            ]
            
            if image_data:
                return self._save_base64_image(image_data[0], f"modern_{location}_{uuid.uuid4().hex[:8]}")
                
        except Exception as e:
            print(f"Error generating modern image: {e}")
        
        return 'https://images.pexels.com/photos/466685/pexels-photo-466685.jpeg?auto=compress&cs=tinysrgb&w=800'
    
    def _generate_cultural_artifact_image(self, location, period):
        """Generate cultural artifact image"""
        prompt = f"Draw cultural artifacts and objects from {location} during {period}. Show tools, art, clothing, pottery, weapons, or other items that were typical of the time and place. Museum-quality presentation, detailed, educational style."
        
        try:
            response = self.client.responses.create(
                model="gpt-4o",
                input=prompt,
                tools=[{
                    "type": "image_generation",
                    "size": "1024x1024",
                    "quality": "high",
                    "format": "png"
                }]
            )
            
            image_data = [
                output.result
                for output in response.output
                if output.type == "image_generation_call"
            ]
            
            if image_data:
                return self._save_base64_image(image_data[0], f"artifacts_{location}_{period}_{uuid.uuid4().hex[:8]}")
                
        except Exception as e:
            print(f"Error generating artifact image: {e}")
        
        return 'https://images.pexels.com/photos/1670187/pexels-photo-1670187.jpeg?auto=compress&cs=tinysrgb&w=800'
    
    def _save_base64_image(self, image_base64, filename):
        """Save base64 image data and return the URL"""
        try:
            image_data = base64.b64decode(image_base64)
            image_file = ContentFile(image_data, name=f"{filename}.png")
            file_path = default_storage.save(f"generated_images/{filename}.png", image_file)
            return default_storage.url(file_path)
        except Exception as e:
            print(f"Error saving image: {e}")
            return None
    
    def _get_period_description(self, time_period):
        """Convert time period code to description"""
        period_map = {
            'ancient': 'Ancient Times (Before 500 CE)',
            'medieval': 'Medieval Period (500-1500 CE)',
            'renaissance': 'Renaissance (1400-1600 CE)',
            'industrial': 'Industrial Revolution (1760-1840)',
            'modern_early': 'Early Modern Period (1900-1950)',
            'modern_late': 'Late Modern Period (1950-2000)',
            'contemporary': 'Contemporary Period (2000-Present)'
        }
        return period_map.get(time_period, time_period)