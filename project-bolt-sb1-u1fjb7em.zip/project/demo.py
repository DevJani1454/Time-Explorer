import openai
import json
import base64
import os
from typing import Dict, List, Any

class HistoricalExplorer:
    def __init__(self, api_key: str = None):
        """
        Initialize the Historical Explorer with OpenAI API key
        
        Args:
            api_key: Your OpenAI API key. If not provided, will try to get from environment
        """
        self.api_key = api_key or os.getenv('OPENAI_API_KEY')
        if not self.api_key:
            print("Warning: No OpenAI API key provided. Using mock data.")
        else:
            self.client = openai.OpenAI(api_key=self.api_key)
    
    def explore_location(self, location: str, time_period: str, content_type: str = "comprehensive") -> Dict[str, Any]:
        """
        Generate comprehensive historical content for a location and time period
        
        Args:
            location: The place to explore (e.g., "Rome", "Paris", "Tokyo")
            time_period: The historical period (e.g., "Ancient Times", "Medieval Period", "1920s")
            content_type: Focus area ("comprehensive", "cultural", "architectural", "lifestyle", "events")
        
        Returns:
            Dictionary containing all generated historical content
        """
        print(f"🏛️  Exploring {location} during {time_period}...")
        print(f"📚 Focus: {content_type}")
        print("-" * 50)
        
        if not self.api_key:
            return self._get_mock_content(location, time_period)
        
        try:
            # Generate different types of content
            narrative = self._generate_narrative(location, time_period, content_type)
            cultural_info = self._generate_cultural_info(location, time_period)
            architectural_details = self._generate_architectural_details(location, time_period)
            lifestyle_description = self._generate_lifestyle_description(location, time_period)
            additional_data = self._generate_additional_data(location, time_period)
            
            # Generate images
            images = self._generate_images(location, time_period)
            
            result = {
                "location": location,
                "time_period": time_period,
                "content_type": content_type,
                "narrative": narrative,
                "cultural_info": cultural_info,
                "architectural_details": architectural_details,
                "lifestyle_description": lifestyle_description,
                "key_facts": additional_data.get("key_facts", []),
                "notable_figures": additional_data.get("notable_figures", []),
                "historical_events": additional_data.get("historical_events", []),
                "images": images
            }
            
            return result
            
        except Exception as e:
            print(f"❌ Error generating content: {e}")
            return self._get_mock_content(location, time_period)
    
    def _generate_narrative(self, location: str, time_period: str, content_type: str) -> str:
        """Generate historical narrative using OpenAI"""
        prompt = f"""Write a comprehensive historical narrative about {location} during {time_period}. 
        Focus on {content_type}. Include:
        - What the area looked like and felt like during this time
        - Major cultural and social aspects
        - Important historical context
        - Daily life of people living there
        - Significant events or changes happening
        
        Write in an engaging, informative style that brings the past to life. Limit to 500 words."""
        
        return self._call_openai_text(prompt)
    
    def _generate_cultural_info(self, location: str, time_period: str) -> str:
        """Generate cultural information"""
        prompt = f"""Provide detailed cultural information about {location} during {time_period}. Include:
        - Religious practices and beliefs
        - Art, music, and literature
        - Social customs and traditions
        - Food and cuisine
        - Clothing and fashion
        - Festivals and celebrations
        
        Be specific and historically accurate. Limit to 400 words."""
        
        return self._call_openai_text(prompt)
    
    def _generate_architectural_details(self, location: str, time_period: str) -> str:
        """Generate architectural information"""
        prompt = f"""Describe the architecture and buildings of {location} during {time_period}. Include:
        - Typical building styles and materials
        - Notable structures or monuments
        - Urban planning and city layout
        - Construction techniques
        - Architectural influences
        - How buildings reflected the culture and society
        
        Be detailed and historically accurate. Limit to 400 words."""
        
        return self._call_openai_text(prompt)
    
    def _generate_lifestyle_description(self, location: str, time_period: str) -> str:
        """Generate lifestyle and daily life information"""
        prompt = f"""Describe daily life and lifestyle in {location} during {time_period}. Include:
        - How people lived day-to-day
        - Work and occupations
        - Family life and social structure
        - Education and learning
        - Entertainment and leisure
        - Transportation and communication
        - Economic activities
        
        Paint a vivid picture of what life was really like. Limit to 400 words."""
        
        return self._call_openai_text(prompt)
    
    def _generate_additional_data(self, location: str, time_period: str) -> Dict[str, Any]:
        """Generate key facts, notable figures, and historical events"""
        prompt = f"""Provide structured information about {location} during {time_period} in JSON format:
        {{
            "key_facts": ["fact1", "fact2", "fact3", "fact4", "fact5"],
            "notable_figures": [
                {{"name": "Person Name", "role": "Their role/significance", "years": "Active years"}},
                {{"name": "Person Name", "role": "Their role/significance", "years": "Active years"}}
            ],
            "historical_events": [
                {{"event": "Event name", "year": "Year", "significance": "Why it was important"}},
                {{"event": "Event name", "year": "Year", "significance": "Why it was important"}}
            ]
        }}
        
        Provide accurate historical information. Return only valid JSON."""
        
        try:
            response = self._call_openai_text(prompt)
            return json.loads(response)
        except (json.JSONDecodeError, Exception) as e:
            print(f"⚠️  Error parsing additional data: {e}")
            return {
                "key_facts": ["Historical data is being compiled..."],
                "notable_figures": [],
                "historical_events": []
            }
    
    def _generate_images(self, location: str, time_period: str) -> Dict[str, str]:
        """Generate historical images using OpenAI's image generation"""
        if not self.api_key:
            return self._get_mock_images()
        
        try:
            # Generate historical visualization
            historical_prompt = f"Draw a detailed historical visualization of {location} during {time_period}. Show the architecture, people in period clothing, daily activities, and the overall atmosphere of the time. Historically accurate, detailed, artistic style."
            historical_image = self._generate_single_image(historical_prompt, f"historical_{location}_{time_period}")
            
            # Generate modern comparison
            modern_prompt = f"Draw a modern photograph of {location} showing contemporary architecture, streets, and urban life. Realistic, high-quality, daytime lighting."
            modern_image = self._generate_single_image(modern_prompt, f"modern_{location}")
            
            # Generate cultural artifacts
            artifact_prompt = f"Draw cultural artifacts and objects from {location} during {time_period}. Show tools, art, clothing, pottery, weapons, or other items that were typical of the time and place. Museum-quality presentation, detailed, educational style."
            artifact_image = self._generate_single_image(artifact_prompt, f"artifacts_{location}_{time_period}")
            
            return {
                "historical_visualization": historical_image,
                "modern_comparison": modern_image,
                "cultural_artifacts": artifact_image
            }
            
        except Exception as e:
            print(f"⚠️  Error generating images: {e}")
            return self._get_mock_images()
    
    def _generate_single_image(self, prompt: str, filename: str) -> str:
        """Generate a single image using OpenAI's new image generation API"""
        try:
            response = self.client.responses.create(
                model="gpt-4o",
                input=f"Generate an image: {prompt}",
                tools=[{
                    "type": "image_generation",
                    "size": "1024x1024",
                    "quality": "high",
                    "format": "png"
                }]
            )
            
            # Extract the image data
            image_data = [
                output.result
                for output in response.output
                if output.type == "image_generation_call"
            ]
            
            if image_data:
                image_base64 = image_data[0]
                # Save the image
                return self._save_image(image_base64, filename)
            else:
                print(f"⚠️  No image data received for {filename}")
                return "Image generation failed"
                
        except Exception as e:
            print(f"⚠️  Error generating image {filename}: {e}")
            return "Image generation failed"
    
    def _save_image(self, image_base64: str, filename: str) -> str:
        """Save base64 image to file"""
        try:
            image_data = base64.b64decode(image_base64)
            filepath = f"{filename}.png"
            
            with open(filepath, "wb") as f:
                f.write(image_data)
            
            print(f"💾 Saved image: {filepath}")
            return filepath
            
        except Exception as e:
            print(f"❌ Error saving image {filename}: {e}")
            return "Failed to save image"
    
    def _call_openai_text(self, prompt: str) -> str:
        """Call OpenAI API for text generation"""
        try:
            response = self.client.chat.completions.create(
                model="gpt-4o",
                messages=[{"role": "user", "content": prompt}],
                max_tokens=1000,
                temperature=0.7
            )
            return response.choices[0].message.content
            
        except Exception as e:
            print(f"❌ Error calling OpenAI API: {e}")
            return f"Error generating content: {e}"
    
    def _get_mock_content(self, location: str, time_period: str) -> Dict[str, Any]:
        """Return mock content when API is not available"""
        return {
            "location": location,
            "time_period": time_period,
            "content_type": "mock",
            "narrative": f"During {time_period}, {location} was a vibrant center of human activity and cultural development. The streets bustled with merchants, artisans, and citizens going about their daily lives in ways both familiar and foreign to our modern eyes. This was a time of both continuity and change, where ancient traditions met new innovations.",
            "cultural_info": f"The cultural life of {location} during {time_period} was rich and multifaceted. Religious practices played a central role in daily life, with ceremonies and festivals marking important seasonal and life transitions. Art and music flourished, often serving both decorative and spiritual purposes.",
            "architectural_details": f"The architectural landscape of {location} during {time_period} showcased the engineering capabilities and aesthetic sensibilities of the era. Buildings were constructed using locally available materials with techniques that had been perfected over generations.",
            "lifestyle_description": f"Daily life in {location} during {time_period} followed rhythms dictated by the sun, seasons, and social obligations. Most people rose early and worked until sunset, with activities varying greatly depending on occupation, social class, and gender.",
            "key_facts": [
                f"{location} was a major center during {time_period}",
                "Population was smaller than today",
                "Buildings used local materials",
                "Life revolved around seasonal changes",
                "Social hierarchy was important"
            ],
            "notable_figures": [
                {"name": "Historical Leader", "role": "Influential ruler", "years": "Active during period"},
                {"name": "Cultural Figure", "role": "Artist or writer", "years": "Contributed to culture"}
            ],
            "historical_events": [
                {"event": "Major Event", "year": "During period", "significance": "Shaped the region"},
                {"event": "Cultural Milestone", "year": "Another year", "significance": "Influenced society"}
            ],
            "images": self._get_mock_images()
        }
    
    def _get_mock_images(self) -> Dict[str, str]:
        """Return mock image URLs"""
        return {
            "historical_visualization": "Mock historical image (API key needed for real generation)",
            "modern_comparison": "Mock modern image (API key needed for real generation)",
            "cultural_artifacts": "Mock artifacts image (API key needed for real generation)"
        }
    
    def print_results(self, results: Dict[str, Any]):
        """Pretty print the exploration results"""
        print(f"\n🏛️  HISTORICAL EXPLORATION RESULTS")
        print(f"📍 Location: {results['location']}")
        print(f"⏰ Time Period: {results['time_period']}")
        print(f"🎯 Content Type: {results['content_type']}")
        print("=" * 60)
        
        print(f"\n📖 HISTORICAL NARRATIVE:")
        print("-" * 30)
        print(results['narrative'])
        
        print(f"\n🎭 CULTURAL INFORMATION:")
        print("-" * 30)
        print(results['cultural_info'])
        
        print(f"\n🏗️  ARCHITECTURAL DETAILS:")
        print("-" * 30)
        print(results['architectural_details'])
        
        print(f"\n🏠 LIFESTYLE & DAILY LIFE:")
        print("-" * 30)
        print(results['lifestyle_description'])
        
        print(f"\n💡 KEY FACTS:")
        print("-" * 30)
        for i, fact in enumerate(results['key_facts'], 1):
            print(f"{i}. {fact}")
        
        print(f"\n👑 NOTABLE FIGURES:")
        print("-" * 30)
        for figure in results['notable_figures']:
            print(f"• {figure['name']} - {figure['role']} ({figure['years']})")
        
        print(f"\n📅 HISTORICAL EVENTS:")
        print("-" * 30)
        for event in results['historical_events']:
            print(f"• {event['event']} ({event['year']}) - {event['significance']}")
        
        print(f"\n🖼️  GENERATED IMAGES:")
        print("-" * 30)
        for image_type, image_path in results['images'].items():
            print(f"• {image_type.replace('_', ' ').title()}: {image_path}")


def main():
    """
    Demo script showing how to use the Historical Explorer
    """
    print("🌟 Historical Explorer Demo")
    print("=" * 50)
    
    # Initialize the explorer
    # Option 1: Provide API key directly
    # explorer = HistoricalExplorer(api_key="your-openai-api-key-here")
    
    # Option 2: Use environment variable OPENAI_API_KEY
    # export OPENAI_API_KEY="your-api-key-here"
    explorer = HistoricalExplorer()
    
    # Example explorations
    examples = [
        {
            "location": "Rome",
            "time_period": "Ancient Times (100 CE)",
            "content_type": "comprehensive"
        },
        {
            "location": "Paris",
            "time_period": "Medieval Period (1200 CE)",
            "content_type": "cultural"
        },
        {
            "location": "Tokyo",
            "time_period": "Edo Period (1700s)",
            "content_type": "lifestyle"
        }
    ]
    
    # Run examples
    for i, example in enumerate(examples, 1):
        print(f"\n🔍 EXAMPLE {i}:")
        results = explorer.explore_location(
            location=example["location"],
            time_period=example["time_period"],
            content_type=example["content_type"]
        )
        explorer.print_results(results)
        
        if i < len(examples):
            print("\n" + "="*80 + "\n")
    
    # Interactive mode
    print(f"\n🎮 INTERACTIVE MODE:")
    print("-" * 30)
    
    try:
        location = input("Enter a location (e.g., London, Cairo, Beijing): ").strip()
        time_period = input("Enter a time period (e.g., Medieval, 1920s, Ancient Rome): ").strip()
        
        content_types = ["comprehensive", "cultural", "architectural", "lifestyle", "events"]
        print(f"Content types: {', '.join(content_types)}")
        content_type = input("Enter content type (or press Enter for 'comprehensive'): ").strip()
        
        if not content_type:
            content_type = "comprehensive"
        
        if location and time_period:
            print(f"\n🚀 Exploring {location} during {time_period}...")
            results = explorer.explore_location(location, time_period, content_type)
            explorer.print_results(results)
        else:
            print("❌ Please provide both location and time period.")
            
    except KeyboardInterrupt:
        print("\n👋 Thanks for using Historical Explorer!")
    except Exception as e:
        print(f"❌ Error in interactive mode: {e}")


if __name__ == "__main__":
    main()