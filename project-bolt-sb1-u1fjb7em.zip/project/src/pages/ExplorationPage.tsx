import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { MapPin, Clock, Calendar, Layers, Search, Sparkles, Volume2, Map, Info } from 'lucide-react';
import FixedPlacesService from '../services/fixedPlacesService';

interface ExplorationData {
  location: string;
  timePeriod: string;
  customYear?: string;
  contentType: string;
}

const ExplorationPage: React.FC = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState<ExplorationData>({
    location: '',
    timePeriod: '',
    customYear: '',
    contentType: 'comprehensive'
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [loadingStage, setLoadingStage] = useState('');

  const fixedPlacesService = new FixedPlacesService();

  const timePeriods = [
    { value: 'ancient', label: 'Ancient Times (Before 500 CE)' },
    { value: 'medieval', label: 'Medieval Period (500-1500 CE)' },
    { value: 'renaissance', label: 'Renaissance (1400-1600 CE)' },
    { value: 'industrial', label: 'Industrial Revolution (1760-1840)' },
    { value: 'modern_early', label: 'Early Modern (1900-1950)' },
    { value: 'modern_late', label: 'Late Modern (1950-2000)' },
    { value: 'contemporary', label: 'Contemporary (2000-Present)' },
    { value: 'custom', label: 'Custom Time Period' }
  ];

  const contentTypes = [
    { 
      value: 'comprehensive', 
      label: 'Complete Package', 
      description: 'Everything: culture, architecture, lifestyle, images',
      icon: '🌍'
    },
    { 
      value: 'cultural_focus', 
      label: 'Cultural Focus', 
      description: 'Traditions, customs, social life, festivals',
      icon: '👥'
    },
    { 
      value: 'architectural', 
      label: 'Architecture', 
      description: 'Buildings, structures, urban planning, design',
      icon: '🏛️'
    },
    { 
      value: 'lifestyle', 
      label: 'Daily Life', 
      description: 'How people lived, worked, and played',
      icon: '🏠'
    },
    { 
      value: 'events', 
      label: 'Historical Events', 
      description: 'Politics, wars, major happenings, timeline',
      icon: '📜'
    }
  ];

  const featuredLocations = [
    { location: 'Rome', period: 'ancient', display: 'Ancient Rome (100 CE)' },
    { location: 'Paris', period: 'medieval', display: 'Medieval Paris (1200 CE)' },
    { location: 'Florence', period: 'renaissance', display: 'Renaissance Florence (1450 CE)' },
    { location: 'London', period: 'industrial', display: 'Industrial London (1800 CE)' },
    { location: 'New York', period: 'custom', customYear: '1920s', display: 'Jazz Age New York (1920s)' }
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.location || !formData.timePeriod) return;

    setIsSubmitting(true);
    
    try {
      // Check if this is a featured location
      const isAvailable = fixedPlacesService.isLocationAvailable(formData.location, formData.timePeriod, formData.customYear);
      
      if (isAvailable) {
        // Quick loading for featured locations
        const stages = [
          'Accessing historical database...',
          'Loading comprehensive data...',
          'Preparing content...'
        ];

        for (let i = 0; i < stages.length; i++) {
          setLoadingStage(stages[i]);
          await new Promise(resolve => setTimeout(resolve, 600));
        }
      } else {
        // Longer loading simulation for non-featured locations
        const stages = [
          'Initializing research systems...',
          'Searching historical archives...',
          'Consulting ancient texts...',
          'Analyzing archaeological evidence...',
          'Cross-referencing sources...',
          'Validating historical accuracy...',
          'Compiling comprehensive data...'
        ];

        for (let i = 0; i < stages.length; i++) {
          setLoadingStage(stages[i]);
          await new Promise(resolve => setTimeout(resolve, 1000));
        }
      }
      
      // Store exploration data for results page
      const explorationData = {
        ...formData,
        id: Date.now(),
        timestamp: new Date().toISOString()
      };
      
      sessionStorage.setItem('currentExploration', JSON.stringify(explorationData));
      navigate('/results');
    } catch (error) {
      console.error('Error starting exploration:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const selectFeaturedLocation = (featured: any) => {
    setFormData({
      location: featured.location,
      timePeriod: featured.period,
      customYear: featured.customYear || '',
      contentType: 'comprehensive'
    });
  };

  const isCurrentLocationFeatured = () => {
    return fixedPlacesService.isLocationAvailable(formData.location, formData.timePeriod, formData.customYear);
  };

  return (
    <div className="min-h-screen pt-20 py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center space-y-6 mb-12">
          <div className="flex items-center justify-center space-x-3">
            <Sparkles className="w-8 h-8 text-gold animate-glow" />
            <h1 className="text-4xl sm:text-5xl font-serif font-bold text-white">
              Historical Time Explorer
            </h1>
            <Sparkles className="w-8 h-8 text-gold animate-glow" />
          </div>
          <p className="text-xl text-gray-300 font-mono max-w-2xl mx-auto">
            Discover the rich history, culture, architecture, and daily life of any location across different time periods.
          </p>
          
          {/* Featured Locations Banner */}
          <div className="glass-effect rounded-lg p-4 max-w-3xl mx-auto">
            <div className="flex items-center justify-center space-x-2 mb-3">
              <Sparkles className="w-5 h-5 text-gold" />
              <span className="text-gold font-mono font-semibold">Featured Locations (Instant Results)</span>
              <Sparkles className="w-5 h-5 text-gold" />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2 text-sm">
              {featuredLocations.map((featured, index) => (
                <button
                  key={index}
                  onClick={() => selectFeaturedLocation(featured)}
                  className="text-gray-300 hover:text-gold font-mono transition-colors text-left p-2 rounded hover:bg-gray-800"
                >
                  • {featured.display}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-8">
          <div className="glass-effect rounded-xl p-8 space-y-8">
            {/* Location Input */}
            <div className="space-y-3">
              <label className="flex items-center space-x-2 text-lg font-serif font-semibold text-gold">
                <MapPin className="w-5 h-5" />
                <span>Location</span>
              </label>
              <input
                type="text"
                value={formData.location}
                onChange={(e) => setFormData(prev => ({ ...prev, location: e.target.value }))}
                placeholder="e.g., Rome, Paris, Florence, London, New York..."
                className="w-full bg-gray-800 border border-gray-600 rounded-lg px-4 py-3 text-white font-mono focus:border-gold focus:ring-2 focus:ring-gold focus:ring-opacity-20 transition-all"
                required
              />
              <div className="flex items-start space-x-2">
                <Info className="w-4 h-4 text-blue-400 mt-0.5 flex-shrink-0" />
                <p className="text-sm text-gray-400 font-mono">
                  💡 Featured locations provide instant, comprehensive results. Other locations will show extended loading.
                </p>
              </div>
            </div>

            {/* Time Period Selection */}
            <div className="space-y-3">
              <label className="flex items-center space-x-2 text-lg font-serif font-semibold text-gold">
                <Clock className="w-5 h-5" />
                <span>Time Period</span>
              </label>
              <select
                value={formData.timePeriod}
                onChange={(e) => setFormData(prev => ({ ...prev, timePeriod: e.target.value }))}
                className="w-full bg-gray-800 border border-gray-600 rounded-lg px-4 py-3 text-white font-mono focus:border-gold focus:ring-2 focus:ring-gold focus:ring-opacity-20 transition-all"
                required
              >
                <option value="">Select a time period...</option>
                {timePeriods.map(period => (
                  <option key={period.value} value={period.value}>
                    {period.label}
                  </option>
                ))}
              </select>
            </div>

            {/* Custom Year Input */}
            {formData.timePeriod === 'custom' && (
              <div className="space-y-3">
                <label className="flex items-center space-x-2 text-lg font-serif font-semibold text-gold">
                  <Calendar className="w-5 h-5" />
                  <span>Custom Year/Period</span>
                </label>
                <input
                  type="text"
                  value={formData.customYear}
                  onChange={(e) => setFormData(prev => ({ ...prev, customYear: e.target.value }))}
                  placeholder="e.g., 1920s, 1066, 500 BCE, Victorian Era..."
                  className="w-full bg-gray-800 border border-gray-600 rounded-lg px-4 py-3 text-white font-mono focus:border-gold focus:ring-2 focus:ring-gold focus:ring-opacity-20 transition-all"
                />
                <p className="text-sm text-gray-400 font-mono">
                  💡 Be specific: "1920s", "1347 (Black Death)", "1969 (Moon Landing)"
                </p>
              </div>
            )}

            {/* Content Type Selection */}
            <div className="space-y-4">
              <label className="flex items-center space-x-2 text-lg font-serif font-semibold text-gold">
                <Layers className="w-5 h-5" />
                <span>Focus Area</span>
              </label>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {contentTypes.map(type => (
                  <div
                    key={type.value}
                    onClick={() => setFormData(prev => ({ ...prev, contentType: type.value }))}
                    className={`cursor-pointer p-4 rounded-lg border-2 transition-all hover:scale-105 ${
                      formData.contentType === type.value
                        ? 'border-gold bg-gold bg-opacity-10 shadow-lg'
                        : 'border-gray-600 hover:border-gray-500'
                    }`}
                  >
                    <div className="text-center space-y-2">
                      <div className="text-3xl">{type.icon}</div>
                      <h3 className="font-serif font-semibold text-white">{type.label}</h3>
                      <p className="text-sm text-gray-300 font-mono">{type.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Status Indicator */}
            {formData.location && formData.timePeriod && (
              <div className={`rounded-lg p-4 border ${
                isCurrentLocationFeatured() 
                  ? 'border-green-500 bg-green-500 bg-opacity-10' 
                  : 'border-yellow-500 bg-yellow-500 bg-opacity-10'
              }`}>
                <div className="flex items-center space-x-2">
                  <div className={`w-3 h-3 rounded-full ${
                    isCurrentLocationFeatured() ? 'bg-green-500' : 'bg-yellow-500'
                  } animate-pulse`}></div>
                  <span className={`font-mono font-semibold ${
                    isCurrentLocationFeatured() ? 'text-green-400' : 'text-yellow-400'
                  }`}>
                    {isCurrentLocationFeatured() 
                      ? '✅ Featured Location - Instant Results' 
                      : '⚠️ Extended Research Required'
                    }
                  </span>
                </div>
                <p className="text-sm text-gray-300 font-mono mt-2">
                  {isCurrentLocationFeatured() 
                    ? 'This location has comprehensive curated data available for immediate access.'
                    : 'This location will require extended research time and may show continuous loading.'
                  }
                </p>
              </div>
            )}

            {/* What You'll Get Preview */}
            <div className="bg-gray-800 rounded-lg p-6 border border-gray-600">
              <h3 className="text-lg font-serif font-semibold text-gold mb-4 flex items-center space-x-2">
                <Sparkles className="w-5 h-5" />
                <span>What You'll Get</span>
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm font-mono text-gray-300">
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <span className="text-gold">📖</span>
                    <span>Rich historical narratives (800+ words)</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="text-gold">🎭</span>
                    <span>Cultural customs & traditions</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="text-gold">🏛️</span>
                    <span>Architectural details & styles</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="text-gold">🏠</span>
                    <span>Daily life & lifestyle details</span>
                  </div>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <span className="text-gold">🖼️</span>
                    <span>Historical images & visualizations</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="text-gold">👑</span>
                    <span>Notable figures & events</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="text-gold">💡</span>
                    <span>Key historical facts</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="text-gold">📊</span>
                    <span>Downloadable reports</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Submit Button */}
          <div className="text-center">
            <button
              type="submit"
              disabled={!formData.location || !formData.timePeriod || isSubmitting}
              className="group relative bg-gradient-to-r from-gold to-ancient-bronze text-gray-900 px-10 py-4 rounded-lg font-mono font-bold text-lg disabled:opacity-50 disabled:cursor-not-allowed hover:from-yellow-400 hover:to-yellow-600 transition-all duration-300 transform hover:scale-105 shadow-lg"
            >
              {isSubmitting ? (
                <div className="flex items-center space-x-2">
                  <div className="w-5 h-5 border-2 border-gray-900 border-t-transparent rounded-full animate-spin"></div>
                  <span>{loadingStage || 'Generating Historical Content...'}</span>
                </div>
              ) : (
                <div className="flex items-center space-x-2">
                  <Search className="w-5 h-5 group-hover:animate-pulse" />
                  <span>Begin Historical Exploration</span>
                  <Sparkles className="w-5 h-5 group-hover:animate-pulse" />
                </div>
              )}
            </button>
            
            <div className="mt-4 space-y-2">
              <p className="text-sm text-gray-400 font-mono">
                Featured locations provide instant comprehensive results
              </p>
              <p className="text-xs text-gray-500 font-mono">
                Powered by curated historical database and AI technology
              </p>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ExplorationPage;