import React, { useState } from 'react';
import { MapPin, Filter, Shuffle, Calendar, Users, Globe } from 'lucide-react';

interface CommunityVision {
  id: string;
  location: string;
  ancestry: string;
  title: string;
  snippet: string;
  timestamp: string;
  coordinates: [number, number];
}

const CommunityPage: React.FC = () => {
  const [selectedFilter, setSelectedFilter] = useState<string>('all');
  const [selectedVision, setSelectedVision] = useState<CommunityVision | null>(null);

  // Mock community data
  const communityVisions: CommunityVision[] = [
    {
      id: '1',
      location: 'Tokyo, Japan',
      ancestry: 'East Asian',
      title: 'Neon Dreams of Ancient Spirits',
      snippet: 'The electric dragons dance between glass towers, their light-breath warming the metal hearts of our steel ancestors...',
      timestamp: '2 hours ago',
      coordinates: [35.6762, 139.6503]
    },
    {
      id: '2',
      location: 'Reykjavik, Iceland',
      ancestry: 'Germanic/Norse',
      title: 'Where Odin\'s Ravens See Wifi Signals',
      snippet: 'The invisible threads of Loki\'s web connect every soul in this realm of ice and fire...',
      timestamp: '5 hours ago',
      coordinates: [64.1466, -21.9426]
    },
    {
      id: '3',
      location: 'Cairo, Egypt',
      ancestry: 'Middle Eastern/Persian',
      title: 'Pharaoh\'s Vision of the Digital Nile',
      snippet: 'The great river now flows with streams of light, carrying the prayers of millions across the eternal desert...',
      timestamp: '1 day ago',
      coordinates: [30.0444, 31.2357]
    },
    {
      id: '4',
      location: 'São Paulo, Brazil',
      ancestry: 'Indigenous American',
      title: 'Jaguar Spirit in Concrete Jungle',
      snippet: 'The sacred jaguar prowls through canyons of stone, its spots reflecting the countless windows of modern caves...',
      timestamp: '2 days ago',
      coordinates: [-23.5505, -46.6333]
    },
    {
      id: '5',
      location: 'Dublin, Ireland',
      ancestry: 'Celtic/Irish',
      title: 'Banshee\'s Lament for Silicon Dreams',
      snippet: 'The old songs echo through fiber optic harps, weaving tales of silicon fairies and digital druids...',
      timestamp: '3 days ago',
      coordinates: [53.3498, -6.2603]
    },
    {
      id: '6',
      location: 'Mumbai, India',
      ancestry: 'South Asian',
      title: 'Ganesha\'s Blessing on Digital Pathways',
      snippet: 'The remover of obstacles now clears the paths of data streams, blessing each connection with ancient wisdom...',
      timestamp: '1 week ago',
      coordinates: [19.0760, 72.8777]
    }
  ];

  const cultures = ['all', 'Celtic/Irish', 'Germanic/Norse', 'East Asian', 'Indigenous American', 'Middle Eastern/Persian', 'South Asian'];

  const filteredVisions = selectedFilter === 'all' 
    ? communityVisions 
    : communityVisions.filter(vision => vision.ancestry === selectedFilter);

  const getRandomVision = () => {
    const randomIndex = Math.floor(Math.random() * communityVisions.length);
    setSelectedVision(communityVisions[randomIndex]);
  };

  return (
    <div className="min-h-screen pt-20 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center space-y-6 mb-12">
          <h1 className="text-4xl sm:text-5xl font-serif font-bold text-white">
            Global Community Timeline
          </h1>
          <p className="text-xl text-gray-300 font-mono max-w-3xl mx-auto">
            Explore visions from cultures worldwide. Each pin represents a unique ancestral perspective 
            on modern life, contributed by our global community.
          </p>
        </div>

        {/* Controls */}
        <div className="flex flex-col sm:flex-row gap-4 justify-between items-center mb-8 glass-effect rounded-xl p-6">
          <div className="flex items-center space-x-4">
            <Filter className="w-5 h-5 text-gold" />
            <select
              value={selectedFilter}
              onChange={(e) => setSelectedFilter(e.target.value)}
              className="bg-gray-800 border border-gray-600 rounded-lg px-4 py-2 text-white font-mono focus:border-gold transition-colors"
            >
              {cultures.map(culture => (
                <option key={culture} value={culture}>
                  {culture === 'all' ? 'All Cultures' : culture}
                </option>
              ))}
            </select>
          </div>
          
          <button
            onClick={getRandomVision}
            className="flex items-center space-x-2 bg-gold text-gray-900 px-6 py-2 rounded-lg font-mono font-semibold hover:bg-yellow-400 transition-colors"
          >
            <Shuffle className="w-4 h-4" />
            <span>Random Vision</span>
          </button>
        </div>

        {/* Map Placeholder */}
        <div className="mb-8">
          <div className="glass-effect rounded-xl overflow-hidden">
            <div className="aspect-video bg-gradient-to-br from-gray-800 to-gray-900 relative">
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center space-y-4">
                  <Globe className="w-16 h-16 text-gold mx-auto animate-float" />
                  <p className="text-gray-300 font-mono">Interactive World Map</p>
                  <p className="text-sm text-gray-500 font-mono">
                    Click pins to explore community visions
                  </p>
                </div>
              </div>
              
              {/* Mock pins on the map */}
              <div className="absolute top-1/4 left-1/4 w-4 h-4 bg-gold rounded-full animate-glow cursor-pointer"></div>
              <div className="absolute top-1/3 right-1/3 w-4 h-4 bg-mystic-purple rounded-full animate-glow cursor-pointer"></div>
              <div className="absolute bottom-1/3 left-1/2 w-4 h-4 bg-deep-indigo rounded-full animate-glow cursor-pointer"></div>
              <div className="absolute bottom-1/4 right-1/4 w-4 h-4 bg-ancient-bronze rounded-full animate-glow cursor-pointer"></div>
            </div>
          </div>
        </div>

        {/* Vision Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          {filteredVisions.map((vision) => (
            <div
              key={vision.id}
              onClick={() => setSelectedVision(vision)}
              className="glass-effect rounded-xl p-6 cursor-pointer hover:border-gold transition-all duration-300 group"
            >
              <div className="space-y-4">
                <div className="flex items-start justify-between">
                  <div className="flex items-center space-x-2">
                    <MapPin className="w-4 h-4 text-gold flex-shrink-0" />
                    <span className="text-sm text-gray-300 font-mono">{vision.location}</span>
                  </div>
                  <span className="text-xs text-gray-500 font-mono">{vision.timestamp}</span>
                </div>
                
                <div className="space-y-2">
                  <h3 className="text-lg font-serif font-semibold text-white group-hover:text-gold transition-colors">
                    {vision.title}
                  </h3>
                  <p className="text-sm text-gray-400 font-mono bg-gradient-to-r from-gold to-ancient-bronze bg-clip-text text-transparent">
                    {vision.ancestry}
                  </p>
                </div>
                
                <p className="text-gray-300 font-mono text-sm leading-relaxed">
                  {vision.snippet}
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* Selected Vision Modal */}
        {selectedVision && (
          <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4">
            <div className="glass-effect rounded-xl max-w-2xl w-full max-h-[80vh] overflow-y-auto">
              <div className="p-8 space-y-6">
                <div className="flex justify-between items-start">
                  <div className="space-y-2">
                    <h2 className="text-2xl font-serif font-bold text-white">
                      {selectedVision.title}
                    </h2>
                    <div className="flex items-center space-x-4">
                      <div className="flex items-center space-x-2">
                        <MapPin className="w-4 h-4 text-gold" />
                        <span className="text-gray-300 font-mono">{selectedVision.location}</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Users className="w-4 h-4 text-mystic-purple" />
                        <span className="text-gray-300 font-mono">{selectedVision.ancestry}</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Calendar className="w-4 h-4 text-deep-indigo" />
                        <span className="text-gray-300 font-mono">{selectedVision.timestamp}</span>
                      </div>
                    </div>
                  </div>
                  
                  <button
                    onClick={() => setSelectedVision(null)}
                    className="text-gray-400 hover:text-white transition-colors"
                  >
                    ✕
                  </button>
                </div>
                
                <div className="prose prose-invert max-w-none">
                  <blockquote className="border-l-4 border-gold pl-6 italic text-lg text-gray-200 font-serif leading-relaxed">
                    {selectedVision.snippet}
                  </blockquote>
                </div>
                
                <div className="flex justify-center space-x-4">
                  <button className="bg-gold text-gray-900 px-6 py-2 rounded-lg font-mono font-semibold hover:bg-yellow-400 transition-colors">
                    View Full Vision
                  </button>
                  <button
                    onClick={getRandomVision}
                    className="border border-gold text-gold px-6 py-2 rounded-lg font-mono font-semibold hover:bg-gold hover:text-gray-900 transition-colors"
                  >
                    Next Random
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="glass-effect rounded-xl p-6 text-center">
            <div className="text-3xl font-serif font-bold text-gold mb-2">127</div>
            <div className="text-gray-300 font-mono text-sm">Total Visions</div>
          </div>
          
          <div className="glass-effect rounded-xl p-6 text-center">
            <div className="text-3xl font-serif font-bold text-mystic-purple mb-2">42</div>
            <div className="text-gray-300 font-mono text-sm">Countries</div>
          </div>
          
          <div className="glass-effect rounded-xl p-6 text-center">
            <div className="text-3xl font-serif font-bold text-deep-indigo mb-2">18</div>
            <div className="text-gray-300 font-mono text-sm">Cultures</div>
          </div>
          
          <div className="glass-effect rounded-xl p-6 text-center">
            <div className="text-3xl font-serif font-bold text-ancient-bronze mb-2">2.5k</div>
            <div className="text-gray-300 font-mono text-sm">Community Members</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CommunityPage;