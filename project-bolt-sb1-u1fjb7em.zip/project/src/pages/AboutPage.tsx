import React from 'react';
import { Brain, Palette, Globe, Zap, Clock, Users } from 'lucide-react';

const AboutPage: React.FC = () => {
  const technologies = [
    { name: 'OpenAI GPT-4', description: 'Advanced historical content generation', icon: Brain },
    { name: 'DALL·E 3', description: 'AI-powered historical visualizations', icon: Palette },
    { name: 'React + TypeScript', description: 'Modern web application framework', icon: Users },
    { name: 'Tailwind CSS', description: 'Beautiful, responsive design system', icon: Globe },
    { name: 'Vite', description: 'Fast development and build tools', icon: Zap },
    { name: 'Bolt.new', description: 'Rapid development platform', icon: Clock },
  ];

  const timeline = [
    { era: '50,000 BCE', event: 'First human storytelling traditions', culture: 'Oral histories begin' },
    { era: '3200 BCE', event: 'Written language emerges', culture: 'Mesopotamian cuneiform' },
    { era: '800 BCE', event: 'Epic poetry traditions', culture: 'Homer\'s Iliad and Odyssey' },
    { era: '1440 CE', event: 'Printing press revolution', culture: 'Mass distribution of stories' },
    { era: '1920s', event: 'Radio storytelling', culture: 'Voices reach millions' },
    { era: '2024', event: 'AI-powered historical exploration', culture: 'Time Explorer launches' },
  ];

  return (
    <div className="min-h-screen pt-20 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Hero Section */}
        <div className="text-center space-y-8 mb-16">
          <h1 className="text-4xl sm:text-5xl font-serif font-bold text-white">
            About Time Explorer
          </h1>
          <div className="max-w-4xl mx-auto space-y-6">
            <p className="text-xl text-gray-300 font-mono leading-relaxed">
              Time Explorer revolutionizes historical research through AI. We don't just preserve history — we bring it to life.
            </p>
            <p className="text-lg text-gray-400 font-mono leading-relaxed">
              Our platform bridges the gap between past and present, allowing you to explore any location 
              across different time periods with comprehensive historical intelligence.
            </p>
          </div>
        </div>

        {/* Mission Statement */}
        <section className="mb-16">
          <div className="glass-effect rounded-xl p-8 text-center">
            <h2 className="text-3xl font-serif font-bold text-gold mb-6">Our Mission</h2>
            <blockquote className="text-xl text-gray-200 font-serif italic leading-relaxed max-w-4xl mx-auto">
              "To make history accessible and engaging for everyone by providing comprehensive, 
              AI-powered insights into how places looked, felt, and functioned throughout different time periods."
            </blockquote>
          </div>
        </section>

        {/* Technology Stack */}
        <section className="mb-16">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-serif font-bold text-white mb-4">
              Powered by Cutting-Edge Technology
            </h2>
            <p className="text-lg text-gray-300 font-mono max-w-3xl mx-auto">
              We leverage the latest in AI and web technologies to create immersive historical experiences.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {technologies.map((tech, index) => (
              <div key={index} className="glass-effect rounded-xl p-6 text-center hover:border-gold transition-all duration-300 group">
                <div className="w-16 h-16 mx-auto mb-4 bg-gold bg-opacity-20 rounded-full flex items-center justify-center group-hover:animate-glow">
                  <tech.icon className="w-8 h-8 text-gold" />
                </div>
                <h3 className="text-lg font-serif font-semibold text-white mb-2">{tech.name}</h3>
                <p className="text-gray-300 font-mono text-sm">{tech.description}</p>
              </div>
            ))}
          </div>
        </section>

        {/* Timeline */}
        <section className="mb-16">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-serif font-bold text-white mb-4">
              The Evolution of Historical Knowledge
            </h2>
            <p className="text-lg text-gray-300 font-mono max-w-3xl mx-auto">
              From cave paintings to AI-powered exploration - humanity's eternal quest to understand and share our past.
            </p>
          </div>
          
          <div className="relative">
            {/* Timeline Line */}
            <div className="absolute left-1/2 transform -translate-x-px h-full w-0.5 bg-gradient-to-b from-gold via-mystic-purple to-deep-indigo"></div>
            
            <div className="space-y-12">
              {timeline.map((item, index) => (
                <div key={index} className={`flex items-center ${index % 2 === 0 ? 'flex-row' : 'flex-row-reverse'}`}>
                  <div className={`w-1/2 ${index % 2 === 0 ? 'pr-8 text-right' : 'pl-8 text-left'}`}>
                    <div className="glass-effect rounded-xl p-6">
                      <div className="space-y-2">
                        <h3 className="text-xl font-serif font-bold text-gold">{item.era}</h3>
                        <h4 className="text-lg font-serif font-semibold text-white">{item.event}</h4>
                        <p className="text-gray-300 font-mono text-sm">{item.culture}</p>
                      </div>
                    </div>
                  </div>
                  
                  {/* Timeline Dot */}
                  <div className="w-4 h-4 bg-gold rounded-full border-4 border-gray-900 z-10 animate-glow"></div>
                  
                  <div className="w-1/2"></div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Vision */}
        <section className="mb-16">
          <div className="glass-effect rounded-xl p-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
              <div className="space-y-6">
                <h2 className="text-3xl font-serif font-bold text-white">Our Vision</h2>
                <div className="space-y-4 text-gray-300 font-mono">
                  <p>
                    We believe that understanding our past is crucial to navigating our future. 
                    By exploring historical contexts, we gain wisdom that transcends time.
                  </p>
                  <p>
                    Time Explorer serves as a bridge between past and present, not to escape reality, 
                    but to enrich it with the depth of human experience across generations.
                  </p>
                  <p>
                    Through AI-powered content generation and intuitive interfaces, we're creating 
                    new ways to explore, understand, and learn from our collective human heritage.
                  </p>
                </div>
              </div>
              
              <div className="text-center">
                <div className="w-48 h-48 mx-auto relative">
                  <div className="absolute inset-0 bg-gradient-to-r from-gold to-ancient-bronze rounded-full opacity-20 animate-pulse"></div>
                  <div className="absolute inset-4 bg-gradient-to-r from-mystic-purple to-deep-indigo rounded-full opacity-30 animate-pulse delay-300"></div>
                  <div className="absolute inset-8 bg-gradient-to-r from-deep-indigo to-gold rounded-full opacity-40 animate-pulse delay-700"></div>
                  <div className="absolute inset-16 flex items-center justify-center">
                    <Globe className="w-16 h-16 text-gold animate-float" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Credits */}
        <section>
          <div className="text-center space-y-8">
            <h2 className="text-3xl font-serif font-bold text-white">Built With Gratitude</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto">
              {['OpenAI', 'React', 'TypeScript', 'Tailwind', 'Vite', 'Bolt.new', 'Netlify', 'Lucide'].map((service) => (
                <div key={service} className="glass-effect rounded-lg p-4 text-center">
                  <span className="text-gold font-mono font-semibold">{service}</span>
                </div>
              ))}
            </div>
            <p className="text-gray-400 font-mono max-w-2xl mx-auto">
              Special thanks to all the technology partners and open-source projects 
              that make Time Explorer possible.
            </p>
          </div>
        </section>
      </div>
    </div>
  );
};

export default AboutPage;