import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, BookOpen, Image, Users, Crown, Castle, Palette, Cog, Sparkles, Volume2, Map, Zap } from 'lucide-react';

const HomePage: React.FC = () => {
  const hasApiKeys = import.meta.env.VITE_OPENAI_API_KEY && 
                    import.meta.env.VITE_ELEVENLABS_API_KEY && 
                    import.meta.env.VITE_GOOGLE_MAPS_API_KEY;

  return (
    <div className="min-h-screen pt-20">
      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-10 left-10 w-20 h-20 border border-gold rounded-full animate-pulse"></div>
          <div className="absolute top-40 right-20 w-12 h-12 bg-gold opacity-30 rounded-full animate-float"></div>
          <div className="absolute bottom-20 left-1/4 w-16 h-16 border border-mystic-purple rounded-full animate-pulse"></div>
          <div className="absolute bottom-40 right-1/3 w-8 h-8 bg-deep-indigo opacity-40 rounded-full animate-float"></div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="text-center space-y-8">
            <div className="space-y-4">
              <h1 className="text-4xl sm:text-6xl lg:text-7xl font-serif font-bold leading-tight">
                <span className="block text-white">Explore Any Place</span>
                <span className="block ancestor-glow bg-clip-text text-transparent">
                  Through Time
                </span>
                <span className="block text-white">& History</span>
              </h1>
              
              <p className="text-xl sm:text-2xl text-gray-300 font-mono max-w-3xl mx-auto">
                Discover the rich history, culture, and stories of any location across different time periods with AI
              </p>

              {/* API Status Banner */}
              <div className="glass-effect rounded-lg p-4 max-w-2xl mx-auto border border-gold">
                <div className="flex items-center justify-center space-x-2 mb-2">
                  {hasApiKeys ? (
                    <>
                      <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
                      <Sparkles className="w-5 h-5 text-gold animate-glow" />
                      <span className="text-gold font-mono font-semibold">FULL AI POWER ACTIVE</span>
                      <Sparkles className="w-5 h-5 text-gold animate-glow" />
                      <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
                    </>
                  ) : (
                    <>
                      <div className="w-3 h-3 bg-yellow-500 rounded-full animate-pulse"></div>
                      <span className="text-yellow-400 font-mono font-semibold">DEMO MODE</span>
                      <div className="w-3 h-3 bg-yellow-500 rounded-full animate-pulse"></div>
                    </>
                  )}
                </div>
                <p className="text-sm text-gray-300 font-mono">
                  {hasApiKeys 
                    ? 'Real AI generation with OpenAI GPT-4, DALL-E 3, ElevenLabs & Google Maps'
                    : 'Enhanced demo with high-quality mock data. Add API keys for real AI generation.'
                  }
                </p>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-6 justify-center items-center">
              <Link
                to="/explore"
                className="group relative bg-gold text-gray-900 px-8 py-4 rounded-lg font-mono font-medium text-lg hover:bg-yellow-400 transition-all duration-300 transform hover:scale-105 flex items-center space-x-2"
              >
                <span>Start Historical Exploration</span>
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </Link>
              
              <Link
                to="/about"
                className="px-8 py-4 border border-gold text-gold rounded-lg font-mono font-medium text-lg hover:bg-gold hover:text-gray-900 transition-all duration-300"
              >
                Learn More
              </Link>
            </div>

            {/* AI Features Preview */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-2xl mx-auto mt-8">
              <div className="glass-effect rounded-lg p-3 text-center">
                <Sparkles className="w-6 h-6 text-gold mx-auto mb-1" />
                <p className="text-xs text-gray-300 font-mono">GPT-4 Content</p>
              </div>
              <div className="glass-effect rounded-lg p-3 text-center">
                <Image className="w-6 h-6 text-mystic-purple mx-auto mb-1" />
                <p className="text-xs text-gray-300 font-mono">DALL-E 3 Images</p>
              </div>
              <div className="glass-effect rounded-lg p-3 text-center">
                <Volume2 className="w-6 h-6 text-deep-indigo mx-auto mb-1" />
                <p className="text-xs text-gray-300 font-mono">AI Audio</p>
              </div>
              <div className="glass-effect rounded-lg p-3 text-center">
                <Map className="w-6 h-6 text-ancient-bronze mx-auto mb-1" />
                <p className="text-xs text-gray-300 font-mono">Maps Data</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 border-t border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center space-y-12">
            <h2 className="text-3xl sm:text-4xl font-serif font-bold text-white">
              AI-Powered Historical Intelligence
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="group glass-effect rounded-xl p-8 hover:border-gold transition-all duration-300">
                <div className="text-center space-y-4">
                  <div className="w-16 h-16 mx-auto bg-gold bg-opacity-20 rounded-full flex items-center justify-center group-hover:animate-glow">
                    <BookOpen className="w-8 h-8 text-gold" />
                  </div>
                  <h3 className="text-xl font-serif font-semibold text-white">Rich AI Narratives</h3>
                  <p className="text-gray-300 font-mono">
                    Get detailed stories generated by GPT-4 about how places looked, felt, and functioned throughout history.
                  </p>
                </div>
              </div>

              <div className="group glass-effect rounded-xl p-8 hover:border-mystic-purple transition-all duration-300">
                <div className="text-center space-y-4">
                  <div className="w-16 h-16 mx-auto bg-mystic-purple bg-opacity-20 rounded-full flex items-center justify-center group-hover:animate-glow">
                    <Image className="w-8 h-8 text-mystic-purple" />
                  </div>
                  <h3 className="text-xl font-serif font-semibold text-white">DALL-E 3 Visualizations</h3>
                  <p className="text-gray-300 font-mono">
                    See historically accurate HD images of locations, architecture, artifacts, and daily life from any time period.
                  </p>
                </div>
              </div>

              <div className="group glass-effect rounded-xl p-8 hover:border-deep-indigo transition-all duration-300">
                <div className="text-center space-y-4">
                  <div className="w-16 h-16 mx-auto bg-deep-indigo bg-opacity-20 rounded-full flex items-center justify-center group-hover:animate-glow">
                    <Volume2 className="w-8 h-8 text-deep-indigo" />
                  </div>
                  <h3 className="text-xl font-serif font-semibold text-white">AI Voice Narration</h3>
                  <p className="text-gray-300 font-mono">
                    Listen to ElevenLabs AI-generated audio narration that brings historical content to life.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Time Periods Section */}
      <section className="py-20 border-t border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center space-y-12">
            <h2 className="text-3xl sm:text-4xl font-serif font-bold text-white">
              Explore Any Time Period
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="glass-effect rounded-xl p-6 text-center hover:border-gold transition-all duration-300">
                <Crown className="w-12 h-12 text-gold mx-auto mb-4" />
                <h3 className="text-lg font-serif font-semibold text-white mb-2">Ancient Times</h3>
                <p className="text-gray-300 font-mono text-sm">Before 500 CE</p>
              </div>
              
              <div className="glass-effect rounded-xl p-6 text-center hover:border-mystic-purple transition-all duration-300">
                <Castle className="w-12 h-12 text-mystic-purple mx-auto mb-4" />
                <h3 className="text-lg font-serif font-semibold text-white mb-2">Medieval</h3>
                <p className="text-gray-300 font-mono text-sm">500-1500 CE</p>
              </div>
              
              <div className="glass-effect rounded-xl p-6 text-center hover:border-deep-indigo transition-all duration-300">
                <Palette className="w-12 h-12 text-deep-indigo mx-auto mb-4" />
                <h3 className="text-lg font-serif font-semibold text-white mb-2">Renaissance</h3>
                <p className="text-gray-300 font-mono text-sm">1400-1600 CE</p>
              </div>
              
              <div className="glass-effect rounded-xl p-6 text-center hover:border-ancient-bronze transition-all duration-300">
                <Cog className="w-12 h-12 text-ancient-bronze mx-auto mb-4" />
                <h3 className="text-lg font-serif font-semibold text-white mb-2">Industrial</h3>
                <p className="text-gray-300 font-mono text-sm">1760-1840</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* API Features Section */}
      {hasApiKeys && (
        <section className="py-20 border-t border-gray-700">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center space-y-8">
              <h2 className="text-3xl sm:text-4xl font-serif font-bold text-white">
                Full AI Power Activated
              </h2>
              <p className="text-xl text-gray-300 font-mono max-w-3xl mx-auto">
                Experience the complete Time Explorer with real AI generation, HD images, voice narration, and enhanced location data.
              </p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <div className="glass-effect rounded-xl p-6 text-center">
                  <div className="w-12 h-12 mx-auto mb-4 bg-green-500 bg-opacity-20 rounded-full flex items-center justify-center">
                    <Sparkles className="w-6 h-6 text-green-400" />
                  </div>
                  <h3 className="text-lg font-serif font-semibold text-white mb-2">OpenAI GPT-4</h3>
                  <p className="text-gray-300 font-mono text-sm">Real AI content generation</p>
                </div>
                
                <div className="glass-effect rounded-xl p-6 text-center">
                  <div className="w-12 h-12 mx-auto mb-4 bg-green-500 bg-opacity-20 rounded-full flex items-center justify-center">
                    <Image className="w-6 h-6 text-green-400" />
                  </div>
                  <h3 className="text-lg font-serif font-semibold text-white mb-2">DALL-E 3</h3>
                  <p className="text-gray-300 font-mono text-sm">HD historical images</p>
                </div>
                
                <div className="glass-effect rounded-xl p-6 text-center">
                  <div className="w-12 h-12 mx-auto mb-4 bg-green-500 bg-opacity-20 rounded-full flex items-center justify-center">
                    <Volume2 className="w-6 h-6 text-green-400" />
                  </div>
                  <h3 className="text-lg font-serif font-semibold text-white mb-2">ElevenLabs</h3>
                  <p className="text-gray-300 font-mono text-sm">AI voice narration</p>
                </div>
                
                <div className="glass-effect rounded-xl p-6 text-center">
                  <div className="w-12 h-12 mx-auto mb-4 bg-green-500 bg-opacity-20 rounded-full flex items-center justify-center">
                    <Map className="w-6 h-6 text-green-400" />
                  </div>
                  <h3 className="text-lg font-serif font-semibold text-white mb-2">Google Maps</h3>
                  <p className="text-gray-300 font-mono text-sm">Enhanced location data</p>
                </div>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* CTA Section */}
      <section className="py-20 border-t border-gray-700">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-8">
          <h2 className="text-3xl sm:text-4xl font-serif font-bold text-white">
            Ready to Journey Through Time?
          </h2>
          <p className="text-xl text-gray-300 font-mono">
            Enter any location and time period to discover its rich history, culture, and stories with AI.
          </p>
          <Link
            to="/explore"
            className="inline-flex items-center space-x-2 bg-gradient-to-r from-gold to-ancient-bronze text-gray-900 px-10 py-5 rounded-lg font-mono font-bold text-lg hover:from-yellow-400 hover:to-yellow-600 transition-all duration-300 transform hover:scale-105 animate-glow"
          >
            <span>Begin AI Historical Exploration</span>
            <ArrowRight className="w-6 h-6" />
          </Link>
          
          {hasApiKeys && (
            <p className="text-sm text-green-400 font-mono">
              🚀 Full AI power ready - Real generation with your API keys
            </p>
          )}
        </div>
      </section>
    </div>
  );
};

export default HomePage;