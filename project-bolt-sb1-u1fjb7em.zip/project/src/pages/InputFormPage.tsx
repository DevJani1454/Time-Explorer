import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Upload, MapPin, Users, Wand2, Camera, Mic, Video } from 'lucide-react';

interface FormData {
  location: string;
  ancestry: string;
  artifact: File | null;
  displayMode: 'narrative-visual' | 'visual-only' | 'full-experience';
}

const InputFormPage: React.FC = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState<FormData>({
    location: '',
    ancestry: '',
    artifact: null,
    displayMode: 'narrative-visual'
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const ancestryOptions = [
    'Celtic/Irish', 'Germanic/Norse', 'Mediterranean/Roman', 'Slavic/Eastern European',
    'Indigenous American', 'African/Sub-Saharan', 'East Asian', 'South Asian',
    'Middle Eastern/Persian', 'Aboriginal Australian', 'Pacific Islander',
    'Scandinavian', 'Custom/Mixed Heritage'
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.location || !formData.ancestry) return;

    setIsSubmitting(true);
    
    // Simulate AI processing
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    // Store form data for results page
    sessionStorage.setItem('ancestorVisionData', JSON.stringify(formData));
    navigate('/results');
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && file.size <= 10 * 1024 * 1024) { // 10MB limit
      setFormData(prev => ({ ...prev, artifact: file }));
    }
  };

  return (
    <div className="min-h-screen pt-20 py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center space-y-6 mb-12">
          <h1 className="text-4xl sm:text-5xl font-serif font-bold text-white">
            Vision Quest
          </h1>
          <p className="text-xl text-gray-300 font-mono max-w-2xl mx-auto">
            Share your location and heritage to summon your ancestor's perspective 
            on the modern world around you.
          </p>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-8">
          <div className="glass-effect rounded-xl p-8 space-y-8">
            {/* Location Input */}
            <div className="space-y-3">
              <label className="flex items-center space-x-2 text-lg font-serif font-semibold text-gold">
                <MapPin className="w-5 h-5" />
                <span>Current Location</span>
              </label>
              <input
                type="text"
                value={formData.location}
                onChange={(e) => setFormData(prev => ({ ...prev, location: e.target.value }))}
                placeholder="e.g., New York City, Tokyo, London..."
                className="w-full bg-gray-800 border border-gray-600 rounded-lg px-4 py-3 text-white font-mono focus:border-gold focus:ring-2 focus:ring-gold focus:ring-opacity-20 transition-all"
                required
              />
            </div>

            {/* Ancestry Selection */}
            <div className="space-y-3">
              <label className="flex items-center space-x-2 text-lg font-serif font-semibold text-gold">
                <Users className="w-5 h-5" />
                <span>Cultural Heritage</span>
              </label>
              <select
                value={formData.ancestry}
                onChange={(e) => setFormData(prev => ({ ...prev, ancestry: e.target.value }))}
                className="w-full bg-gray-800 border border-gray-600 rounded-lg px-4 py-3 text-white font-mono focus:border-gold focus:ring-2 focus:ring-gold focus:ring-opacity-20 transition-all"
                required
              >
                <option value="">Select your ancestry...</option>
                {ancestryOptions.map(option => (
                  <option key={option} value={option}>{option}</option>
                ))}
              </select>
            </div>

            {/* Artifact Upload */}
            <div className="space-y-3">
              <label className="flex items-center space-x-2 text-lg font-serif font-semibold text-gold">
                <Upload className="w-5 h-5" />
                <span>Cultural Artifact (Optional)</span>
              </label>
              <div className="border-2 border-dashed border-gray-600 rounded-lg p-6 text-center hover:border-gold transition-colors">
                <input
                  type="file"
                  onChange={handleFileUpload}
                  accept="image/*,.pdf,.txt"
                  className="hidden"
                  id="artifact-upload"
                />
                <label htmlFor="artifact-upload" className="cursor-pointer">
                  <Upload className="w-12 h-12 text-gray-400 mx-auto mb-3" />
                  <p className="text-gray-300 font-mono">
                    {formData.artifact ? formData.artifact.name : 'Upload an image, story, or artifact description (max 10MB)'}
                  </p>
                </label>
              </div>
            </div>

            {/* Display Mode Selection */}
            <div className="space-y-4">
              <label className="flex items-center space-x-2 text-lg font-serif font-semibold text-gold">
                <Wand2 className="w-5 h-5" />
                <span>Experience Mode</span>
              </label>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div
                  onClick={() => setFormData(prev => ({ ...prev, displayMode: 'narrative-visual' }))}
                  className={`cursor-pointer p-4 rounded-lg border-2 transition-all ${
                    formData.displayMode === 'narrative-visual'
                      ? 'border-gold bg-gold bg-opacity-10'
                      : 'border-gray-600 hover:border-gray-500'
                  }`}
                >
                  <div className="text-center space-y-2">
                    <Camera className="w-8 h-8 mx-auto text-gold" />
                    <h3 className="font-serif font-semibold text-white">Narrative + Visual</h3>
                    <p className="text-sm text-gray-300 font-mono">Written story with artistic imagery</p>
                  </div>
                </div>

                <div
                  onClick={() => setFormData(prev => ({ ...prev, displayMode: 'visual-only' }))}
                  className={`cursor-pointer p-4 rounded-lg border-2 transition-all ${
                    formData.displayMode === 'visual-only'
                      ? 'border-gold bg-gold bg-opacity-10'
                      : 'border-gray-600 hover:border-gray-500'
                  }`}
                >
                  <div className="text-center space-y-2">
                    <div className="w-8 h-8 mx-auto bg-mystic-purple rounded-full flex items-center justify-center">
                      <Camera className="w-5 h-5 text-white" />
                    </div>
                    <h3 className="font-serif font-semibold text-white">Visual Only</h3>
                    <p className="text-sm text-gray-300 font-mono">Pure artistic interpretation</p>
                  </div>
                </div>

                <div
                  onClick={() => setFormData(prev => ({ ...prev, displayMode: 'full-experience' }))}
                  className={`cursor-pointer p-4 rounded-lg border-2 transition-all ${
                    formData.displayMode === 'full-experience'
                      ? 'border-gold bg-gold bg-opacity-10'
                      : 'border-gray-600 hover:border-gray-500'
                  }`}
                >
                  <div className="text-center space-y-2">
                    <Video className="w-8 h-8 mx-auto text-deep-indigo" />
                    <h3 className="font-serif font-semibold text-white">Full Experience</h3>
                    <p className="text-sm text-gray-300 font-mono">Story + visuals + audio + video</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Submit Button */}
          <div className="text-center">
            <button
              type="submit"
              disabled={!formData.location || !formData.ancestry || isSubmitting}
              className="group relative bg-gradient-to-r from-gold to-ancient-bronze text-gray-900 px-10 py-4 rounded-lg font-mono font-bold text-lg disabled:opacity-50 disabled:cursor-not-allowed hover:from-yellow-400 hover:to-yellow-600 transition-all duration-300 transform hover:scale-105"
            >
              {isSubmitting ? (
                <div className="flex items-center space-x-2">
                  <div className="w-5 h-5 border-2 border-gray-900 border-t-transparent rounded-full animate-spin"></div>
                  <span>Summoning Ancestor's Vision...</span>
                </div>
              ) : (
                <div className="flex items-center space-x-2">
                  <Wand2 className="w-5 h-5 group-hover:animate-pulse" />
                  <span>Summon Ancestor's Lens</span>
                </div>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default InputFormPage;