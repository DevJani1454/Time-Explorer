import React, { useState, useEffect } from 'react';
import { Clock, Eye, Package, BookOpen, Users, Building, Home, Lightbulb, Crown, Calendar, Search, Sparkles, Download, Volume2, Play, Pause, MapPin } from 'lucide-react';
import { Link } from 'react-router-dom';
import AIService from '../services/aiService';
import FixedPlacesService from '../services/fixedPlacesService';

interface ExplorationData {
  id: number;
  location: string;
  timePeriod: string;
  customYear?: string;
  contentType: string;
  timestamp: string;
}

interface HistoricalContent {
  narrative: string;
  culturalInfo: string;
  architecturalDetails: string;
  lifestyleDescription: string;
  keyFacts: string[];
  notableFigures: Array<{
    name: string;
    role: string;
    years: string;
  }>;
  historicalEvents: Array<{
    event: string;
    year: string;
    significance: string;
  }>;
  images: {
    historicalVisualization: string;
    modernComparison: string;
    culturalArtifacts: string;
  };
  audioNarration?: string;
  locationData?: any;
}

const ResultsPage: React.FC = () => {
  const [explorationData, setExplorationData] = useState<ExplorationData | null>(null);
  const [content, setContent] = useState<HistoricalContent | null>(null);
  const [activeTab, setActiveTab] = useState('narrative');
  const [isLoading, setIsLoading] = useState(true);
  const [loadingStage, setLoadingStage] = useState('Initializing systems...');
  const [isPlaying, setIsPlaying] = useState(false);
  const [audio, setAudio] = useState<HTMLAudioElement | null>(null);
  const [isFixedPlace, setIsFixedPlace] = useState(false);
  const [showInfiniteLoading, setShowInfiniteLoading] = useState(false);

  const aiService = new AIService();
  const fixedPlacesService = new FixedPlacesService();

  useEffect(() => {
    const data = sessionStorage.getItem('currentExploration');
    if (data) {
      const exploration = JSON.parse(data);
      setExplorationData(exploration);
      generateContent(exploration);
    } else {
      setIsLoading(false);
    }
  }, []);

  const generateContent = async (exploration: ExplorationData) => {
    setIsLoading(true);
    
    try {
      const period = exploration.timePeriod === 'custom' ? exploration.customYear : exploration.timePeriod;
      
      // Check if this is a fixed place
      const isFixed = fixedPlacesService.isLocationAvailable(exploration.location, exploration.timePeriod, exploration.customYear);
      setIsFixedPlace(isFixed);

      if (isFixed) {
        // Quick loading for fixed places
        const stages = [
          'Accessing historical database...',
          'Loading comprehensive data...',
          'Preparing content...'
        ];

        for (let i = 0; i < stages.length; i++) {
          setLoadingStage(stages[i]);
          await new Promise(resolve => setTimeout(resolve, 600));
        }

        const fixedContent = await fixedPlacesService.generateHistoricalContent(
          exploration.location,
          exploration.timePeriod,
          exploration.contentType,
          exploration.customYear
        );

        setContent(fixedContent);
        setIsLoading(false);
      } else {
        // Show infinite loading for non-fixed places
        setShowInfiniteLoading(true);
        
        const infiniteStages = [
          'Searching historical archives...',
          'Consulting ancient texts...',
          'Analyzing archaeological evidence...',
          'Cross-referencing sources...',
          'Validating historical accuracy...',
          'Compiling comprehensive data...',
          'Processing cultural information...',
          'Generating detailed analysis...',
          'Finalizing historical content...',
          'Almost ready...'
        ];

        let stageIndex = 0;
        const stageInterval = setInterval(() => {
          setLoadingStage(infiniteStages[stageIndex % infiniteStages.length]);
          stageIndex++;
        }, 2000);

        // Keep loading indefinitely for non-fixed places
        // In a real implementation, you might want to show a message after some time
        setTimeout(() => {
          clearInterval(stageInterval);
          setLoadingStage('This location requires additional research. Please try one of our featured locations.');
        }, 20000);

        return; // Don't set isLoading to false for infinite loading
      }

    } catch (error) {
      console.error('Error generating content:', error);
      setContent(getMockContent(exploration.location, exploration.timePeriod));
      setIsLoading(false);
    }
  };

  const toggleAudio = () => {
    if (!audio) return;

    if (isPlaying) {
      audio.pause();
      setIsPlaying(false);
    } else {
      audio.play();
      setIsPlaying(true);
    }
  };

  const getPeriodDisplay = (period: string) => {
    const periodMap: { [key: string]: string } = {
      'ancient': 'Ancient Times (Before 500 CE)',
      'medieval': 'Medieval Period (500-1500 CE)',
      'renaissance': 'Renaissance (1400-1600 CE)',
      'industrial': 'Industrial Revolution (1760-1840)',
      'modern_early': 'Early Modern (1900-1950)',
      'modern_late': 'Late Modern (1950-2000)',
      'contemporary': 'Contemporary (2000-Present)'
    };
    return periodMap[period] || period;
  };

  const getMockContent = (location: string, period: string): HistoricalContent => {
    return {
      narrative: `During ${period}, ${location} was a vibrant center of human activity and cultural development...`,
      culturalInfo: `The cultural life of ${location} during ${period} was rich and multifaceted...`,
      architecturalDetails: `The architectural landscape of ${location} during ${period} showcased...`,
      lifestyleDescription: `Daily life in ${location} during ${period} followed rhythms...`,
      keyFacts: [`${location} was a major center during ${period}`, 'Population was smaller than today'],
      notableFigures: [{ name: 'Historical Leader', role: 'Influential ruler', years: 'Active during period' }],
      historicalEvents: [{ event: 'Major Event', year: 'During period', significance: 'Shaped the region' }],
      images: {
        historicalVisualization: 'https://images.pexels.com/photos/1670187/pexels-photo-1670187.jpeg?auto=compress&cs=tinysrgb&w=800',
        modernComparison: 'https://images.pexels.com/photos/466685/pexels-photo-466685.jpeg?auto=compress&cs=tinysrgb&w=800',
        culturalArtifacts: 'https://images.pexels.com/photos/1007025/pexels-photo-1007025.jpeg?auto=compress&cs=tinysrgb&w=800'
      }
    };
  };

  const downloadContent = () => {
    if (!content || !explorationData) return;

    const fullContent = `
TIME EXPLORER - HISTORICAL EXPLORATION REPORT
Generated by Time Explorer

Location: ${explorationData.location}
Time Period: ${explorationData.timePeriod === 'custom' ? explorationData.customYear : getPeriodDisplay(explorationData.timePeriod)}
Content Focus: ${explorationData.contentType}
Generated: ${new Date().toLocaleDateString()}
Data Source: ${isFixedPlace ? 'Curated Historical Database' : 'AI Generation'}

HISTORICAL NARRATIVE:
${content.narrative}

CULTURAL INFORMATION:
${content.culturalInfo}

ARCHITECTURAL DETAILS:
${content.architecturalDetails}

LIFESTYLE & DAILY LIFE:
${content.lifestyleDescription}

KEY FACTS:
${content.keyFacts.map((fact, i) => `${i + 1}. ${fact}`).join('\n')}

NOTABLE FIGURES:
${content.notableFigures.map(figure => `• ${figure.name} - ${figure.role} (${figure.years})`).join('\n')}

HISTORICAL EVENTS:
${content.historicalEvents.map(event => `• ${event.event} (${event.year}) - ${event.significance}`).join('\n')}

---
Generated by Time Explorer
Visit: https://time-explorer.app
    `;

    const blob = new Blob([fullContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${explorationData.location}_${explorationData.timePeriod}_exploration.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  if (isLoading || showInfiniteLoading) {
    return (
      <div className="min-h-screen pt-20 flex items-center justify-center">
        <div className="text-center space-y-6 max-w-md">
          <div className="relative">
            <div className="w-24 h-24 border-4 border-gold border-t-transparent rounded-full animate-spin mx-auto"></div>
            <Sparkles className="w-10 h-10 text-gold absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 animate-pulse" />
          </div>
          <div className="space-y-2">
            <p className="text-xl text-gray-300 font-mono">{loadingStage}</p>
            {showInfiniteLoading ? (
              <div className="space-y-3">
                <p className="text-sm text-yellow-400 font-mono">
                  This location is not in our curated database
                </p>
                <div className="glass-effect rounded-lg p-4">
                  <p className="text-sm text-gray-300 font-mono mb-3">
                    Try one of our featured locations for instant results:
                  </p>
                  <div className="space-y-1 text-xs text-gold font-mono">
                    {fixedPlacesService.getAvailableLocations().map((loc, i) => (
                      <div key={i}>• {loc}</div>
                    ))}
                  </div>
                </div>
                <Link
                  to="/explore"
                  className="inline-flex items-center space-x-2 bg-gold text-gray-900 px-4 py-2 rounded-lg font-mono font-semibold hover:bg-yellow-400 transition-colors text-sm"
                >
                  <Search className="w-4 h-4" />
                  <span>Try Featured Location</span>
                </Link>
              </div>
            ) : (
              <p className="text-sm text-gray-500 font-mono">
                Loading comprehensive historical content
              </p>
            )}
          </div>
        </div>
      </div>
    );
  }

  if (!explorationData || !content) {
    return (
      <div className="min-h-screen pt-20 flex items-center justify-center">
        <div className="text-center space-y-4">
          <p className="text-xl text-gray-300 font-mono">No exploration data found.</p>
          <Link
            to="/explore"
            className="inline-flex items-center space-x-2 bg-gold text-gray-900 px-6 py-3 rounded-lg font-mono font-semibold hover:bg-yellow-400 transition-colors"
          >
            <Search className="w-5 h-5" />
            <span>Start New Exploration</span>
          </Link>
        </div>
      </div>
    );
  }

  const tabs = [
    { id: 'narrative', label: 'Historical Narrative', icon: BookOpen },
    { id: 'cultural', label: 'Culture & Society', icon: Users },
    { id: 'architecture', label: 'Architecture', icon: Building },
    { id: 'lifestyle', label: 'Daily Life', icon: Home }
  ];

  return (
    <div className="min-h-screen pt-20 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center space-y-4 mb-8">
          <div className="flex items-center justify-center space-x-3">
            <Sparkles className="w-6 h-6 text-gold animate-glow" />
            <h1 className="text-3xl sm:text-4xl font-serif font-bold text-white">
              {explorationData.location} Through Time
            </h1>
            <Sparkles className="w-6 h-6 text-gold animate-glow" />
          </div>
          <p className="text-lg text-gold font-mono">
            {explorationData.timePeriod === 'custom' 
              ? explorationData.customYear 
              : getPeriodDisplay(explorationData.timePeriod)
            }
          </p>
          
          {/* Location Data */}
          {content.locationData && (
            <div className="flex items-center justify-center space-x-4 text-sm text-gray-400 font-mono">
              <div className="flex items-center space-x-1">
                <MapPin className="w-4 h-4" />
                <span>{content.locationData.formattedAddress}</span>
              </div>
              {content.locationData.coordinates && (
                <span>
                  {content.locationData.coordinates.lat.toFixed(4)}, {content.locationData.coordinates.lng.toFixed(4)}
                </span>
              )}
            </div>
          )}
          
          <div className="flex items-center justify-center space-x-4 flex-wrap gap-2">
            <div className="glass-effect rounded-lg px-4 py-2">
              <span className="text-sm text-gray-300 font-mono">
                {isFixedPlace ? '📚 Curated Historical Data' : '✨ AI-Generated Content'}
              </span>
            </div>
            {content.audioNarration && (
              <button
                onClick={toggleAudio}
                className="flex items-center space-x-2 bg-deep-indigo hover:bg-indigo-600 text-white px-4 py-2 rounded-lg font-mono text-sm transition-colors"
              >
                {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                <span>{isPlaying ? 'Pause' : 'Play'} Narration</span>
              </button>
            )}
            <button
              onClick={downloadContent}
              className="flex items-center space-x-2 bg-gray-700 hover:bg-gray-600 text-white px-4 py-2 rounded-lg font-mono text-sm transition-colors"
            >
              <Download className="w-4 h-4" />
              <span>Download Report</span>
            </button>
          </div>
        </div>

        {/* Image Gallery */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          {/* Historical Visualization */}
          <div className="space-y-4">
            <h2 className="text-xl font-serif font-semibold text-white flex items-center space-x-2">
              <div className="w-5 h-5 bg-gold rounded-full animate-glow"></div>
              <span>Historical View</span>
            </h2>
            <div className="glass-effect rounded-xl overflow-hidden">
              <div className="aspect-video relative group">
                <img 
                  src={content.images.historicalVisualization} 
                  alt={`Historical view of ${explorationData.location}`}
                  className="w-full h-full object-cover transition-transform group-hover:scale-105"
                  onError={(e) => {
                    const target = e.target as HTMLImageElement;
                    target.src = 'https://images.pexels.com/photos/1670187/pexels-photo-1670187.jpeg?auto=compress&cs=tinysrgb&w=800';
                  }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
                <div className="absolute bottom-4 left-4 text-white">
                  <p className="font-mono text-sm">🏛️ Historical Visualization</p>
                  <p className="text-xs text-gray-300 font-mono">
                    {isFixedPlace ? 'Curated historical imagery' : 'AI-generated visualization'}
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Modern Comparison */}
          <div className="space-y-4">
            <h2 className="text-xl font-serif font-semibold text-white flex items-center space-x-2">
              <Eye className="w-5 h-5 text-gray-400" />
              <span>Modern View</span>
            </h2>
            <div className="glass-effect rounded-xl overflow-hidden">
              <div className="aspect-video relative group">
                <img 
                  src={content.images.modernComparison} 
                  alt={`Modern view of ${explorationData.location}`}
                  className="w-full h-full object-cover transition-transform group-hover:scale-105"
                  onError={(e) => {
                    const target = e.target as HTMLImageElement;
                    target.src = 'https://images.pexels.com/photos/466685/pexels-photo-466685.jpeg?auto=compress&cs=tinysrgb&w=800';
                  }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
                <div className="absolute bottom-4 left-4 text-white">
                  <p className="font-mono text-sm">📸 Modern Comparison</p>
                  <p className="text-xs text-gray-300 font-mono">Contemporary view</p>
                </div>
              </div>
            </div>
          </div>

          {/* Cultural Artifacts */}
          <div className="space-y-4">
            <h2 className="text-xl font-serif font-semibold text-white flex items-center space-x-2">
              <Package className="w-5 h-5 text-mystic-purple" />
              <span>Cultural Artifacts</span>
            </h2>
            <div className="glass-effect rounded-xl overflow-hidden">
              <div className="aspect-video relative group">
                <img 
                  src={content.images.culturalArtifacts} 
                  alt={`Cultural artifacts from ${explorationData.location}`}
                  className="w-full h-full object-cover transition-transform group-hover:scale-105"
                  onError={(e) => {
                    const target = e.target as HTMLImageElement;
                    target.src = 'https://images.pexels.com/photos/1007025/pexels-photo-1007025.jpeg?auto=compress&cs=tinysrgb&w=800';
                  }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
                <div className="absolute bottom-4 left-4 text-white">
                  <p className="font-mono text-sm">🏺 Cultural Artifacts</p>
                  <p className="text-xs text-gray-300 font-mono">Historical objects</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Content Tabs */}
        <div className="glass-effect rounded-xl p-8 mb-8">
          <div className="flex flex-wrap gap-4 mb-6 border-b border-gray-600 pb-4">
            {tabs.map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center space-x-2 px-6 py-3 rounded-lg font-mono font-semibold transition-all ${
                  activeTab === tab.id
                    ? 'bg-gold text-gray-900'
                    : 'text-gray-300 hover:text-gold border border-gray-600 hover:border-gold'
                }`}
              >
                <tab.icon className="w-4 h-4" />
                <span>{tab.label}</span>
              </button>
            ))}
          </div>

          {/* Tab Content */}
          <div className="space-y-4">
            {activeTab === 'narrative' && (
              <div>
                <h3 className="text-2xl font-serif font-bold text-gold mb-4 flex items-center space-x-2">
                  <Sparkles className="w-6 h-6" />
                  <span>Historical Narrative</span>
                </h3>
                <div className="prose prose-invert max-w-none">
                  <p className="text-gray-200 font-mono leading-relaxed whitespace-pre-line">
                    {content.narrative}
                  </p>
                </div>
              </div>
            )}

            {activeTab === 'cultural' && (
              <div>
                <h3 className="text-2xl font-serif font-bold text-gold mb-4">Culture & Society</h3>
                <div className="prose prose-invert max-w-none">
                  <p className="text-gray-200 font-mono leading-relaxed whitespace-pre-line">
                    {content.culturalInfo}
                  </p>
                </div>
              </div>
            )}

            {activeTab === 'architecture' && (
              <div>
                <h3 className="text-2xl font-serif font-bold text-gold mb-4">Architecture & Buildings</h3>
                <div className="prose prose-invert max-w-none">
                  <p className="text-gray-200 font-mono leading-relaxed whitespace-pre-line">
                    {content.architecturalDetails}
                  </p>
                </div>
              </div>
            )}

            {activeTab === 'lifestyle' && (
              <div>
                <h3 className="text-2xl font-serif font-bold text-gold mb-4">Daily Life & Lifestyle</h3>
                <div className="prose prose-invert max-w-none">
                  <p className="text-gray-200 font-mono leading-relaxed whitespace-pre-line">
                    {content.lifestyleDescription}
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Additional Information */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          {/* Key Facts */}
          <div className="glass-effect rounded-xl p-6">
            <h3 className="text-xl font-serif font-bold text-gold mb-4 flex items-center space-x-2">
              <Lightbulb className="w-5 h-5" />
              <span>Key Facts</span>
            </h3>
            <ul className="space-y-2">
              {content.keyFacts.map((fact, index) => (
                <li key={index} className="text-gray-300 font-mono text-sm flex items-start space-x-2">
                  <span className="text-gold">•</span>
                  <span>{fact}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Notable Figures */}
          <div className="glass-effect rounded-xl p-6">
            <h3 className="text-xl font-serif font-bold text-gold mb-4 flex items-center space-x-2">
              <Crown className="w-5 h-5" />
              <span>Notable Figures</span>
            </h3>
            <div className="space-y-3">
              {content.notableFigures.map((figure, index) => (
                <div key={index} className="border-l-2 border-gold pl-3">
                  <h4 className="text-white font-serif font-semibold">{figure.name}</h4>
                  <p className="text-gray-300 font-mono text-sm">{figure.role}</p>
                  <p className="text-gray-400 font-mono text-xs">{figure.years}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Historical Events */}
          <div className="glass-effect rounded-xl p-6">
            <h3 className="text-xl font-serif font-bold text-gold mb-4 flex items-center space-x-2">
              <Calendar className="w-5 h-5" />
              <span>Historical Events</span>
            </h3>
            <div className="space-y-3">
              {content.historicalEvents.map((event, index) => (
                <div key={index} className="border-l-2 border-mystic-purple pl-3">
                  <h4 className="text-white font-serif font-semibold">{event.event}</h4>
                  <p className="text-gray-300 font-mono text-sm">{event.significance}</p>
                  <p className="text-gray-400 font-mono text-xs">{event.year}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="text-center space-y-4">
          <Link
            to="/explore"
            className="inline-flex items-center space-x-2 bg-gradient-to-r from-gold to-ancient-bronze text-gray-900 px-8 py-3 rounded-lg font-mono font-semibold hover:from-yellow-400 hover:to-yellow-600 transition-all transform hover:scale-105"
          >
            <Search className="w-5 h-5" />
            <span>Explore Another Period</span>
          </Link>
          
          <p className="text-sm text-gray-400 font-mono">
            {isFixedPlace ? 'Curated historical database' : 'Powered by AI technology'}
          </p>
        </div>
      </div>
    </div>
  );
};

export default ResultsPage;