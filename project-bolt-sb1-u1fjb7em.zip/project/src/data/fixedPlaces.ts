// Fixed Places Data for Time Explorer
// This contains curated historical data for instant results

export interface FixedPlaceData {
  narrative: string;
  culturalInfo: string;
  architecturalDetails: string;
  lifestyleDescription: string;
  keyFacts: string[];
  notableFigures: Array<{
    name: string;
    role: string;
    years: string;
  }>;
  historicalEvents: Array<{
    event: string;
    year: string;
    significance: string;
  }>;
  images: {
    historicalVisualization: string;
    modernComparison: string;
    culturalArtifacts: string;
  };
}

export const FIXED_PLACES_DATA: Record<string, FixedPlaceData> = {
  'rome_ancient': {
    narrative: `In the year 100 CE, Rome stood as the beating heart of the greatest empire the world had ever known. The city sprawled across seven hills, its marble temples and monuments gleaming under the Mediterranean sun. The Forum Romanum bustled with senators in white togas, merchants hawking goods from distant provinces, and citizens conducting the business of empire.

The Colosseum, recently completed under the Flavian dynasty, dominated the skyline alongside the Circus Maximus where 250,000 spectators could witness chariot races. Aqueducts carried fresh water from mountain springs across hundreds of miles, feeding public baths, fountains, and private homes. The city's population had swelled to over one million souls - Romans, freedmen, slaves, and foreigners from every corner of the known world.

Streets paved with polygonal stones echoed with the sounds of commerce and conversation in Latin, Greek, and dozens of provincial tongues. The air was thick with the smoke of countless fires, the aroma of bread from public bakeries, and the incense from temples dedicated to gods both Roman and foreign. This was Rome at its zenith - caput mundi, the capital of the world.`,

    culturalInfo: `Roman culture in 100 CE was a sophisticated blend of tradition and cosmopolitan influence. The pantheon of gods - Jupiter, Mars, Venus, and hundreds of others - received daily worship in temples throughout the city. Mystery religions from the East, including Mithraism and early Christianity, were gaining followers among both slaves and citizens.

Social hierarchy was rigid yet permeable. Citizens enjoyed legal protections and voting rights, while freedmen could achieve wealth and influence. Slavery was ubiquitous, with perhaps 30% of the population in bondage, yet manumission offered a path to freedom and citizenship.

Roman entertainment was spectacular and violent. Gladiatorial games, theatrical performances, and chariot racing provided mass entertainment. The wealthy patronized poets like Martial and Juvenal, while public recitations brought literature to the masses. Roman cuisine featured bread, olive oil, wine, and garum (fermented fish sauce), with elaborate banquets displaying exotic delicacies from across the empire.

Education was highly valued among the elite, with rhetoric and philosophy forming the core curriculum. Latin literature flourished under imperial patronage, while Greek remained the language of high culture and learning.`,

    architecturalDetails: `Roman architecture in 100 CE represented the pinnacle of ancient engineering and aesthetic achievement. The revolutionary use of concrete allowed for unprecedented structural innovations - soaring domes, vast interior spaces, and multi-story buildings that defied earlier limitations.

The Forum Romanum showcased imperial grandeur with its marble-clad basilicas, triumphal arches, and towering columns. The recently completed Colosseum demonstrated Roman mastery of the arch and vault, its four-story facade rising 157 feet with a complex system of corridors, chambers, and mechanical lifts beneath the arena floor.

Residential architecture varied dramatically by class. Wealthy Romans lived in spacious domus with central courtyards (atria), elaborate frescoes, and mosaic floors. The poor crowded into multi-story insulae - apartment blocks that could reach six stories high, often poorly constructed and prone to fire.

Roman engineering marvels included the aqueduct system, with eleven major aqueducts supplying the city. The Pantheon, nearing completion, would soon showcase the world's largest unreinforced concrete dome. Public baths like the Baths of Titus featured sophisticated heating systems (hypocausts) and elaborate decorative schemes.

Urban planning followed practical principles with straight roads, efficient sewerage (the Cloaca Maxima), and zoned districts for different activities - commercial, residential, and religious areas clearly delineated.`,

    lifestyleDescription: `Daily life in Rome varied dramatically by social class, but all inhabitants shared the rhythm of a city that never slept. Romans rose before dawn, conducting business in the morning hours when the light was best. The wealthy began their day with the salutatio - a formal reception where clients paid respects to their patrons.

Most Romans lived in cramped quarters and relied on public amenities. They purchased hot food from thermopolia (ancient fast-food shops) since many apartments lacked kitchens. Public fountains provided water, while public latrines served sanitation needs.

The afternoon brought leisure time. Romans flocked to the public baths - not just for cleansing, but for socializing, exercising, and conducting business. These complexes featured hot, warm, and cold pools, exercise areas, libraries, and gardens.

Entertainment was central to Roman life. Gladiatorial games, theatrical performances, and chariot races provided spectacle and social bonding. The wealthy hosted elaborate dinner parties (cenae) featuring multiple courses, entertainment, and philosophical discussion.

Work varied by class and status. Citizens might serve in government, practice law, or engage in trade. Artisans and shopkeepers formed the backbone of the urban economy. Slaves performed everything from household duties to skilled crafts, with some achieving considerable responsibility and eventual freedom.

Family life centered on the paterfamilias, who held absolute authority. Women, while legally subordinate, often wielded significant influence in domestic and social spheres. Children received education based on their family's means and status.`,

    keyFacts: [
      'Rome\'s population exceeded 1 million people, making it the largest city in the ancient world',
      'The Colosseum could hold 50,000-80,000 spectators and featured a complex underground system',
      'Eleven aqueducts supplied Rome with fresh water from sources up to 57 miles away',
      'The city consumed an estimated 400,000 tons of grain annually, much imported from Egypt',
      'Roman concrete was so advanced that many structures still stand today, 2,000 years later',
      'The Forum Romanum served as the political, commercial, and judicial center of the empire',
      'Public baths could accommodate thousands of visitors daily and were centers of social life'
    ],

    notableFigures: [
      {
        name: 'Emperor Trajan',
        role: 'Ruled 98-117 CE, expanded empire to its greatest extent',
        years: '98-117 CE'
      },
      {
        name: 'Pliny the Younger',
        role: 'Lawyer, author, and magistrate who documented daily Roman life',
        years: '61-113 CE'
      },
      {
        name: 'Apollodorus of Damascus',
        role: 'Architect who designed Trajan\'s Forum and Column',
        years: 'Active 100-130 CE'
      },
      {
        name: 'Martial',
        role: 'Poet famous for his epigrams about Roman society',
        years: '40-104 CE'
      }
    ],

    historicalEvents: [
      {
        event: 'Completion of the Colosseum',
        year: '80 CE',
        significance: 'Became the symbol of Roman engineering prowess and imperial power'
      },
      {
        event: 'Eruption of Mount Vesuvius',
        year: '79 CE',
        significance: 'Destroyed Pompeii and Herculaneum, preserving a snapshot of Roman life'
      },
      {
        event: 'Trajan\'s Dacian Wars',
        year: '101-106 CE',
        significance: 'Brought vast wealth to Rome and funded major building projects'
      },
      {
        event: 'Construction of Trajan\'s Forum',
        year: '110 CE',
        significance: 'Represented the pinnacle of Roman architectural achievement'
      }
    ],

    images: {
      historicalVisualization: 'https://images.pexels.com/photos/1670187/pexels-photo-1670187.jpeg?auto=compress&cs=tinysrgb&w=800',
      modernComparison: 'https://images.pexels.com/photos/2064827/pexels-photo-2064827.jpeg?auto=compress&cs=tinysrgb&w=800',
      culturalArtifacts: 'https://images.pexels.com/photos/1007025/pexels-photo-1007025.jpeg?auto=compress&cs=tinysrgb&w=800'
    }
  },

  'paris_medieval': {
    narrative: `In the year 1200 CE, Paris was emerging as one of Europe's most important cities under the reign of Philip Augustus. The city sprawled along both banks of the Seine, connected by the Grand Pont and Petit Pont, with the Île de la Cité serving as its beating heart. Notre-Dame Cathedral was under construction, its Gothic spires reaching toward heaven as a testament to the city's growing wealth and piety.

The narrow, winding streets teemed with merchants, pilgrims, scholars, and craftsmen. The air was filled with the sounds of hammers on anvils, the calls of street vendors, and the chanting of monks from the numerous monasteries. The University of Paris was attracting students from across Europe, making the city a center of learning and theological debate.

Markets flourished along the Right Bank, while the Left Bank housed the growing university community. The royal palace on the Île de la Cité demonstrated the growing power of the Capetian monarchy, while new stone houses replaced older wooden structures, creating a more permanent and impressive urban landscape.`,

    culturalInfo: `Medieval Parisian culture was deeply intertwined with Christian faith and feudal hierarchy. The Catholic Church dominated daily life, with cathedral bells marking the hours and religious festivals punctuating the calendar. Gothic architecture was revolutionizing sacred spaces, emphasizing height, light, and divine transcendence.

Courtly culture was flourishing, with troubadours and trouvères composing chansons de geste and romantic poetry. The University of Paris was becoming Europe's premier center of scholastic learning, where scholars like Peter Abelard debated theology and philosophy.

Guild systems organized craft production, with each trade having its own patron saint, regulations, and ceremonies. The emerging bourgeoisie was challenging traditional feudal structures, while maintaining respect for noble and clerical authority.

French was evolving as a literary language, competing with Latin in secular contexts. Illuminated manuscripts, stone carving, and metalwork reached new heights of artistic achievement under royal and ecclesiastical patronage.`,

    architecturalDetails: `Gothic architecture was transforming Paris in 1200 CE, with Notre-Dame Cathedral representing the pinnacle of this revolutionary style. Flying buttresses, pointed arches, and ribbed vaults allowed for unprecedented height and the creation of vast windows filled with colored glass.

The city's defensive walls, recently expanded by Philip Augustus, enclosed both the Right and Left Banks for the first time. Stone bridges replaced earlier wooden structures, while the royal palace on the Île de la Cité showcased Capetian power with its great hall and chapel.

Residential architecture varied by class. Wealthy merchants built stone houses with shops on the ground floor and living quarters above. The poor crowded into wooden structures that frequently succumbed to fire. Monasteries and churches dotted the landscape, each with its own architectural character.

The Louvre fortress, begun by Philip Augustus, demonstrated the latest in military architecture with its massive keep and defensive walls. Urban planning was beginning to show more organization, with designated areas for different trades and markets.`,

    lifestyleDescription: `Life in medieval Paris revolved around the rhythms of the Church and the seasons. Most inhabitants rose at dawn and retired at sunset, with work patterns dictated by available light. The wealthy enjoyed glass windows and fireplaces, while the poor made do with shutters and braziers.

Guild membership determined one's place in society and economic opportunities. Master craftsmen enjoyed considerable status, while apprentices and journeymen worked toward eventual independence. Women participated in many trades, though their rights were limited by law and custom.

Diet consisted mainly of bread, ale, and seasonal vegetables for the poor, while the wealthy enjoyed meat, wine, and imported spices. Public ovens served neighborhoods, and taverns provided social gathering places.

Education was primarily the domain of the Church, though the University of Paris was attracting secular students. Literacy was limited but growing among the merchant class. Entertainment included religious festivals, mystery plays, and the performances of traveling minstrels.

Sanitation was primitive, with waste disposal a constant challenge. The Seine served multiple purposes - transportation, waste removal, and water supply - creating health hazards that periodically erupted into epidemic disease.`,

    keyFacts: [
      'Notre-Dame Cathedral construction began in 1163 and would continue for nearly 200 years',
      'The University of Paris was founded around 1150 and attracted students from across Europe',
      'Philip Augustus built new city walls that tripled the enclosed area of Paris',
      'The city\'s population was approximately 50,000-100,000 people',
      'Gothic architecture originated in the Île-de-France region around Paris',
      'The Louvre began as a fortress built by Philip Augustus around 1190',
      'Paris was becoming the largest city in Europe north of the Alps'
    ],

    notableFigures: [
      {
        name: 'Philip Augustus',
        role: 'King of France who expanded Paris and built new fortifications',
        years: '1180-1223'
      },
      {
        name: 'Maurice de Sully',
        role: 'Bishop of Paris who initiated construction of Notre-Dame',
        years: '1160-1196'
      },
      {
        name: 'Peter Abelard',
        role: 'Philosopher and theologian who taught at the Cathedral School',
        years: '1079-1142'
      },
      {
        name: 'Suger of Saint-Denis',
        role: 'Abbot who pioneered Gothic architecture',
        years: '1081-1151'
      }
    ],

    historicalEvents: [
      {
        event: 'Beginning of Notre-Dame Construction',
        year: '1163',
        significance: 'Marked Paris as a major center of Gothic architecture'
      },
      {
        event: 'Foundation of University of Paris',
        year: 'c. 1150',
        significance: 'Established Paris as Europe\'s premier center of learning'
      },
      {
        event: 'Construction of Philip Augustus Wall',
        year: '1190-1215',
        significance: 'Tripled the size of enclosed Paris and improved defenses'
      },
      {
        event: 'Battle of Bouvines',
        year: '1214',
        significance: 'Confirmed French power and funded Parisian building projects'
      }
    ],

    images: {
      historicalVisualization: 'https://images.pexels.com/photos/1796730/pexels-photo-1796730.jpeg?auto=compress&cs=tinysrgb&w=800',
      modernComparison: 'https://images.pexels.com/photos/338515/pexels-photo-338515.jpeg?auto=compress&cs=tinysrgb&w=800',
      culturalArtifacts: 'https://images.pexels.com/photos/1001682/pexels-photo-1001682.jpeg?auto=compress&cs=tinysrgb&w=800'
    }
  },

  'florence_renaissance': {
    narrative: `In 1450 CE, Florence stood as the jewel of Renaissance Italy, a city where art, commerce, and humanism converged to create something entirely new in human history. Under the patronage of the Medici family, the city had become a laboratory of artistic innovation and intellectual discovery.

The red-tiled roofs and stone palazzos of Florence stretched along the Arno River, dominated by Brunelleschi's magnificent dome of the Cathedral of Santa Maria del Fiore. In workshops throughout the city, artists like Donatello were revolutionizing sculpture while architects studied ancient Roman texts to rediscover classical principles.

The streets buzzed with the energy of commerce and creativity. Bankers, merchants, and artisans mingled in the Piazza della Signoria, while in private studios, painters experimented with perspective and oil techniques that would transform European art forever. This was the birthplace of the Renaissance, where the medieval world was giving way to modernity.`,

    culturalInfo: `Renaissance Florence was experiencing a cultural revolution that would reshape European civilization. Humanism, with its emphasis on individual dignity and classical learning, was challenging medieval scholasticism. Scholars like Marsilio Ficino were translating Plato and establishing academies devoted to philosophical inquiry.

Art was undergoing radical transformation. Linear perspective, developed by Brunelleschi and refined by artists like Masaccio, created unprecedented realism. Patronage from wealthy families like the Medici enabled artists to experiment and innovate, leading to masterpieces that combined classical themes with Christian symbolism.

Literature flourished in the vernacular, with Dante's Divine Comedy inspiring a generation of poets and writers. The printing press, recently introduced from Germany, was beginning to spread ideas more rapidly than ever before.

Music was evolving from medieval polyphony toward more expressive forms. The carnival songs of Lorenzo de' Medici and the sophisticated madrigals of court composers reflected the city's love of beauty and celebration.

Education emphasized rhetoric, history, and moral philosophy alongside traditional religious instruction. The studia humanitatis was creating a new type of educated citizen, versed in classical literature and capable of civic leadership.`,

    architecturalDetails: `Florentine architecture in 1450 represented a revolutionary return to classical principles combined with innovative engineering. Brunelleschi's dome of the Cathedral, completed in 1436, demonstrated mastery of both Roman techniques and new structural solutions, rising 375 feet without flying buttresses.

The Palazzo Medici, designed by Michelozzo, established the template for Renaissance palace architecture with its rusticated ground floor, elegant upper stories, and classical proportions. The Foundling Hospital (Ospedale degli Innocenti) showcased the new architectural vocabulary of columns, arches, and mathematical harmony.

Churches were being redesigned according to classical principles. San Lorenzo and Santo Spirito, both by Brunelleschi, featured rational geometric plans, classical columns, and harmonious proportions that rejected Gothic verticality in favor of human-scaled spaces.

Urban planning was becoming more systematic. The Oltrarno district was developing with planned streets and squares, while the city center was being beautified with new palaces and public buildings. The Ponte Vecchio, lined with goldsmiths' shops, exemplified the integration of commerce and architecture.

Private palaces featured innovative elements like cortili (courtyards), loggias, and gardens that brought classical villa design into the urban environment. Decorative arts, including intarsia woodwork and ceramic tiles, reached new levels of sophistication.`,

    lifestyleDescription: `Life in Renaissance Florence was marked by unprecedented prosperity and cultural sophistication. The wealthy merchant families lived in magnificent palaces filled with art, books, and luxury goods from across the known world. Their days were spent managing commercial enterprises, patronizing artists, and participating in civic governance.

The guild system remained strong, with the Arte della Lana (wool guild) and Arte di Lana (silk guild) controlling much of the city's economy. Master craftsmen enjoyed high status and considerable wealth, while apprentices learned not just technical skills but also the principles of design and beauty.

Education was highly valued, with wealthy families hiring humanist tutors for their children. The study of Latin and Greek classics was considered essential for proper civic participation. Women, while excluded from formal political life, often received excellent educations and participated actively in cultural patronage.

Daily life revolved around the neighborhood parish and guild affiliations. Markets, festivals, and religious processions provided community bonding. The Carnival season brought elaborate celebrations with pageants, music, and theatrical performances.

Diet reflected both prosperity and trade connections. Wealthy Florentines enjoyed meat, fine wines, and exotic spices, while artisans and workers consumed bread, vegetables, and local wine. The city's numerous taverns and inns served as social gathering places.

Banking and commerce required sophisticated mathematical skills, leading to innovations in accounting and financial instruments. The florin became one of Europe's most trusted currencies, facilitating international trade.`,

    keyFacts: [
      'Brunelleschi\'s dome of Florence Cathedral was the largest in the world when completed in 1436',
      'The Medici Bank had branches across Europe and was the most powerful financial institution of its time',
      'Florence was home to approximately 100,000 people, making it one of Europe\'s largest cities',
      'The city produced more than half of Europe\'s high-quality woolen cloth',
      'Linear perspective was invented in Florence, revolutionizing European art',
      'The Platonic Academy, founded by Cosimo de\' Medici, was the first institution of its kind since antiquity',
      'Florence\'s gold florin was the standard currency for international trade across Europe'
    ],

    notableFigures: [
      {
        name: 'Cosimo de\' Medici',
        role: 'Banker and patron who established Medici power and funded Renaissance art',
        years: '1389-1464'
      },
      {
        name: 'Filippo Brunelleschi',
        role: 'Architect who designed the Cathedral dome and pioneered Renaissance architecture',
        years: '1377-1446'
      },
      {
        name: 'Donatello',
        role: 'Sculptor who created the first free-standing nude since antiquity',
        years: '1386-1466'
      },
      {
        name: 'Marsilio Ficino',
        role: 'Philosopher who translated Plato and founded the Platonic Academy',
        years: '1433-1499'
      }
    ],

    historicalEvents: [
      {
        event: 'Completion of Brunelleschi\'s Dome',
        year: '1436',
        significance: 'Demonstrated Florence\'s architectural supremacy and engineering prowess'
      },
      {
        event: 'Establishment of the Platonic Academy',
        year: '1462',
        significance: 'Made Florence the center of humanist philosophy in Europe'
      },
      {
        event: 'Pazzi Conspiracy',
        year: '1478',
        significance: 'Failed attempt to overthrow the Medici that strengthened their rule'
      },
      {
        event: 'Lorenzo de\' Medici\'s Rule',
        year: '1469-1492',
        significance: 'Golden age of Florentine culture and artistic achievement'
      }
    ],

    images: {
      historicalVisualization: 'https://images.pexels.com/photos/1797161/pexels-photo-1797161.jpeg?auto=compress&cs=tinysrgb&w=800',
      modernComparison: 'https://images.pexels.com/photos/1797161/pexels-photo-1797161.jpeg?auto=compress&cs=tinysrgb&w=800',
      culturalArtifacts: 'https://images.pexels.com/photos/1001682/pexels-photo-1001682.jpeg?auto=compress&cs=tinysrgb&w=800'
    }
  },

  'london_industrial': {
    narrative: `In 1800, London was transforming into the world's first industrial metropolis, a city of unprecedented scale and energy. The Thames flowed dark with coal smoke and industrial waste, while its banks bristled with warehouses, docks, and the skeletal frames of new factories. Steam engines chugged and wheezed throughout the city, powering textile mills, breweries, and the countless workshops that were making Britain the workshop of the world.

The population had exploded to nearly one million souls, making London the largest city on Earth. Elegant Georgian squares housed the wealthy in the West End, while the East End teemed with workers crowded into hastily built tenements. The contrast was stark and growing starker - unprecedented wealth alongside grinding poverty, all fueled by the relentless engine of industrial progress.

Gas lamps were beginning to illuminate the main thoroughfares, pushing back the darkness that had cloaked cities for millennia. The air was thick with coal smoke and the sounds of progress - the clatter of iron wheels on cobblestones, the rhythmic pounding of steam hammers, and the constant hum of human activity that never seemed to cease.`,

    culturalInfo: `Industrial London was a city of dramatic social contrasts and cultural transformation. The emerging middle class was developing new forms of respectability, emphasizing moral improvement, domestic virtue, and rational recreation. Evangelical Christianity was gaining influence, promoting social reform and personal piety.

Working-class culture was being reshaped by industrial rhythms. Traditional rural customs were giving way to urban forms of entertainment - music halls, public houses, and street markets. The gin shops provided escape from harsh working conditions, while Methodist chapels offered spiritual solace and community support.

Literature was reflecting the new urban reality. Gothic novels explored the dark side of progress, while social reformers like Hannah More promoted moral education for the masses. The Royal Academy was establishing artistic standards, though popular culture remained vibrant in street ballads and broadsheets.

Scientific inquiry was flourishing under the influence of the Enlightenment. The Royal Society promoted empirical investigation, while public lectures made scientific knowledge accessible to the educated classes. Industrial innovation was driven by practical experimentation rather than theoretical knowledge.

Fashion was becoming more democratic, with printed cottons and ready-made clothing making style accessible beyond the aristocracy. Coffee houses served as centers of political and commercial discussion, while private clubs provided exclusive spaces for gentlemen's leisure.`,

    architecturalDetails: `London's architecture in 1800 reflected both Georgian elegance and industrial pragmatism. The West End showcased sophisticated urban planning with uniform terraced houses, garden squares, and classical proportions. Bedford Square and Bloomsbury demonstrated how private development could create harmonious residential environments.

Industrial buildings were developing their own aesthetic. Warehouses along the Thames featured massive brick walls and iron-framed windows designed for maximum storage and light. The new docks at West India and London Dock represented cutting-edge engineering with their sophisticated lock systems and specialized storage facilities.

Churches were being built in the classical style, with Hawksmoor's baroque masterpieces complemented by simpler Georgian designs. St. Pancras New Church and All Souls Langham Place demonstrated how classical principles could be adapted to modern urban needs.

Domestic architecture varied dramatically by class. Wealthy merchants built substantial houses with elegant facades, while workers crowded into subdivided older buildings or new tenements with minimal amenities. The contrast between Mayfair mansions and Whitechapel hovels was becoming increasingly stark.

Infrastructure was expanding rapidly. New bridges like Waterloo Bridge (opened 1817) were improving transportation, while the beginnings of the canal system were connecting London to the industrial regions. Street improvements included wider thoroughfares and better paving, though many areas remained medieval in their layout.`,

    lifestyleDescription: `Daily life in industrial London was shaped by the rhythms of factory work and commercial activity. The working day began before dawn for most laborers, who walked through dark streets to mills and workshops where they toiled for twelve to fourteen hours. Factory discipline imposed new forms of time consciousness, with bells and clocks regulating human activity.

The middle classes enjoyed unprecedented comfort and leisure. Their homes featured new conveniences like water closets, coal-fired heating, and gas lighting. Domestic servants managed household tasks, while family life centered on the parlor with its piano, books, and moral instruction.

Diet reflected both abundance and inequality. The wealthy enjoyed varied menus with meat, fresh vegetables, and exotic imports like tea and sugar. Workers subsisted mainly on bread, bacon, and beer, with occasional treats of gin or cheap cuts of meat. Street vendors provided ready-made food for those without cooking facilities.

Transportation was revolutionizing urban life. Hackney carriages served the wealthy, while the poor walked everywhere. The Thames remained a major highway, with watermen ferrying passengers and goods. Stage coaches connected London to the provinces, though travel remained slow and expensive.

Entertainment varied by class. The wealthy attended the opera, theater, and private parties, while workers found recreation in public houses, street fairs, and occasional visits to pleasure gardens like Vauxhall. Boxing matches, cockfighting, and other blood sports remained popular across class lines.

Shopping was becoming more sophisticated, with specialized shops replacing general markets. The wealthy patronized fashionable establishments in Bond Street and Piccadilly, while workers relied on street markets and peddlers for their needs.`,

    keyFacts: [
      'London\'s population reached nearly 1 million by 1800, making it the world\'s largest city',
      'The Port of London handled 80% of Britain\'s imports and 70% of its exports',
      'Gas lighting was introduced to London streets in 1807, the first city to be so illuminated',
      'The Thames was so polluted that it was declared "biologically dead" by contemporary observers',
      'London consumed over 1 million tons of coal annually, creating the world\'s first smog',
      'The city had over 7,000 gin shops, leading to widespread social problems',
      'Life expectancy in working-class areas was as low as 16 years due to disease and pollution'
    ],

    notableFigures: [
      {
        name: 'George III',
        role: 'King during the height of Georgian London\'s development',
        years: '1760-1820'
      },
      {
        name: 'John Nash',
        role: 'Architect who designed Regent Street and transformed London\'s West End',
        years: '1752-1835'
      },
      {
        name: 'William Wilberforce',
        role: 'Social reformer who led the campaign to abolish the slave trade',
        years: '1759-1833'
      },
      {
        name: 'Matthew Boulton',
        role: 'Industrialist who brought steam power to London manufacturing',
        years: '1728-1809'
      }
    ],

    historicalEvents: [
      {
        event: 'Opening of West India Docks',
        year: '1802',
        significance: 'Revolutionized London\'s role as a global trading center'
      },
      {
        event: 'Introduction of Gas Lighting',
        year: '1807',
        significance: 'Made London the first city with public gas illumination'
      },
      {
        event: 'Abolition of Slave Trade',
        year: '1807',
        significance: 'Marked Britain\'s moral leadership and affected London\'s economy'
      },
      {
        event: 'Luddite Riots',
        year: '1811-1816',
        significance: 'Reflected tensions between traditional crafts and industrial progress'
      }
    ],

    images: {
      historicalVisualization: 'https://images.pexels.com/photos/1796730/pexels-photo-1796730.jpeg?auto=compress&cs=tinysrgb&w=800',
      modernComparison: 'https://images.pexels.com/photos/460672/pexels-photo-460672.jpeg?auto=compress&cs=tinysrgb&w=800',
      culturalArtifacts: 'https://images.pexels.com/photos/1001682/pexels-photo-1001682.jpeg?auto=compress&cs=tinysrgb&w=800'
    }
  },

  'new_york_1920s': {
    narrative: `In 1925, New York City pulsed with the electric energy of the Jazz Age, a vertical metropolis reaching toward the sky with unprecedented ambition. The Chrysler Building was rising floor by floor, while the recently completed Woolworth Building stood as the "Cathedral of Commerce," its Gothic spires piercing the Manhattan skyline.

Broadway blazed with electric signs advertising everything from Coca-Cola to the latest theatrical revues. The streets below teemed with Model T Fords, streetcars, and the occasional Rolls-Royce, while elevated trains clattered overhead carrying workers between the boroughs. Prohibition had driven drinking underground, creating a hidden world of speakeasies where jazz music and illegal cocktails flowed freely.

The city was a magnet for dreamers and fortune-seekers from around the world. Ellis Island continued to process thousands of immigrants monthly, while the Harlem Renaissance was transforming African American culture. Wall Street boomed with speculation and easy money, creating millionaires overnight and fueling the construction of ever-taller skyscrapers that seemed to defy gravity itself.`,

    culturalInfo: `The 1920s marked a cultural revolution in New York City, where traditional Victorian values collided with modern urban sensibilities. Jazz music, born in New Orleans, found its most sophisticated expression in Harlem clubs like the Cotton Club and Small's Paradise, where Duke Ellington and Louis Armstrong redefined American music.

The "New Woman" emerged in Manhattan's social scene - bobbed hair, shortened skirts, smoking cigarettes, and demanding equal rights. Flappers danced the Charleston in speakeasies while challenging conventional morality. Greenwich Village became a bohemian enclave where artists, writers, and intellectuals experimented with new forms of expression.

Literature flourished with writers like F. Scott Fitzgerald capturing the era's glamour and disillusionment. The Algonquin Round Table brought together the city's wittiest minds, while magazines like Vanity Fair and The New Yorker defined sophisticated urban culture.

Radio was revolutionizing entertainment, bringing music, news, and drama into homes across the city. Movie palaces like the Roxy and Capitol theaters offered escapist entertainment to millions, while Broadway remained the pinnacle of live performance.

Consumer culture exploded with department stores like Macy's and Bloomingdale's offering mass-produced goods to an increasingly affluent population. Advertising became an art form, promising that happiness could be purchased.`,

    architecturalDetails: `New York's architecture in the 1920s represented the pinnacle of American ambition and technological achievement. The skyscraper had become the city's defining feature, with buildings like the Woolworth Building (1913) and the emerging Chrysler Building pushing the limits of height and engineering.

Art Deco was emerging as the dominant style, combining classical proportions with modern materials and decorative motifs. The Chrysler Building's metallic crown and geometric ornamentation exemplified this new aesthetic, while the Radiator Building demonstrated how commercial architecture could be both functional and beautiful.

Residential architecture varied dramatically by neighborhood. The Upper East Side featured elegant limestone mansions and luxury apartment buildings with elaborate facades and modern amenities. Park Avenue was being transformed into a canyon of luxury residential towers, while the outer boroughs saw rapid development of middle-class housing.

Commercial architecture embraced both grandeur and efficiency. Department stores like Macy's Herald Square combined palatial public spaces with rational organization, while office buildings featured sophisticated elevator systems and modern lighting.

Infrastructure was expanding to support the growing population. The subway system was being extended throughout the boroughs, while new bridges and tunnels connected Manhattan to the surrounding areas. The Holland Tunnel, opened in 1927, represented cutting-edge engineering in underwater construction.

Zoning laws, first implemented in 1916, were shaping the city's development by requiring setbacks that created the characteristic "wedding cake" profile of Manhattan skyscrapers.`,

    lifestyleDescription: `Life in 1920s New York was characterized by unprecedented prosperity, cultural dynamism, and social change. The typical workday had shortened to eight hours for many white-collar workers, creating new leisure time that was filled with entertainment, shopping, and social activities.

The wealthy lived in magnificent apartments on Park Avenue or Fifth Avenue, with servants, automobiles, and country estates. Their social calendar included opera, theater, charity events, and elaborate parties that epitomized the era's excess. Prohibition created a culture of sophisticated lawbreaking, with private clubs and speakeasies serving as social centers.

The growing middle class enjoyed new consumer goods - radios, automobiles, electric appliances, and fashionable clothing. Installment buying made luxury items accessible, while advertising created desires for products that promised to improve one's social status.

Working-class life was improving but remained challenging. Factory workers and service employees benefited from higher wages and shorter hours, but many still lived in crowded tenements. The subway system made it possible to live in the outer boroughs while working in Manhattan, leading to the development of new residential neighborhoods.

Entertainment was central to urban life. Movie theaters offered escape and glamour, while dance halls provided social opportunities for young people. Sports became a mass spectacle, with Yankee Stadium (opened 1923) hosting Babe Ruth and drawing enormous crowds.

Women's roles were changing dramatically. Many worked in offices as secretaries and telephone operators, while others pursued careers in fashion, journalism, and entertainment. The "New Woman" challenged traditional gender roles through her appearance, behavior, and aspirations.

Nightlife flourished despite Prohibition. Speakeasies ranged from elegant establishments serving sophisticated cocktails to rough basement bars. Jazz clubs in Harlem attracted both black and white audiences, though segregation remained the norm in most venues.`,

    keyFacts: [
      'New York\'s population reached 5.6 million by 1920, making it the world\'s second-largest city',
      'The city had over 32,000 speakeasies during Prohibition, more than twice the number of legal bars before 1920',
      'The subway system carried over 2 billion passengers annually by 1925',
      'Wall Street\'s market capitalization reached $87 billion by 1929, up from $27 billion in 1920',
      'The Chrysler Building was the world\'s tallest building when completed in 1930',
      'Harlem\'s population was 73% African American by 1930, up from 10% in 1910',
      'Radio ownership in New York households grew from 1% in 1922 to 40% by 1929'
    ],

    notableFigures: [
      {
        name: 'Jimmy Walker',
        role: 'Flamboyant mayor who embodied the era\'s excess and corruption',
        years: '1926-1932'
      },
      {
        name: 'Duke Ellington',
        role: 'Jazz composer and bandleader who performed at the Cotton Club',
        years: '1899-1974'
      },
      {
        name: 'William Van Alen',
        role: 'Architect who designed the iconic Chrysler Building',
        years: '1883-1954'
      },
      {
        name: 'Texas Guinan',
        role: 'Speakeasy hostess who became the "Queen of the Nightclubs"',
        years: '1884-1933'
      }
    ],

    historicalEvents: [
      {
        event: 'Opening of Yankee Stadium',
        year: '1923',
        significance: 'Became the "House that Ruth Built" and symbol of American sports culture'
      },
      {
        event: 'Harlem Renaissance Peak',
        year: '1925-1929',
        significance: 'Transformed African American culture and influenced American arts'
      },
      {
        event: 'Opening of Holland Tunnel',
        year: '1927',
        significance: 'First mechanically ventilated underwater tunnel, connecting Manhattan to New Jersey'
      },
      {
        event: 'Stock Market Boom',
        year: '1925-1929',
        significance: 'Created unprecedented wealth and speculation that would end in the 1929 crash'
      }
    ],

    images: {
      historicalVisualization: 'https://images.pexels.com/photos/1486222/pexels-photo-1486222.jpeg?auto=compress&cs=tinysrgb&w=800',
      modernComparison: 'https://images.pexels.com/photos/466685/pexels-photo-466685.jpeg?auto=compress&cs=tinysrgb&w=800',
      culturalArtifacts: 'https://images.pexels.com/photos/1001682/pexels-photo-1001682.jpeg?auto=compress&cs=tinysrgb&w=800'
    }
  }
};

export function getFixedPlaceKey(location: string, timePeriod: string, customYear?: string): string {
  const normalizedLocation = location.toLowerCase().trim();
  const period = timePeriod === 'custom' ? 'custom' : timePeriod;
  
  // Handle custom years for specific locations
  if (period === 'custom' && customYear) {
    const normalizedYear = customYear.toLowerCase().trim();
    if (normalizedLocation.includes('new york') && normalizedYear.includes('1920')) {
      return 'new_york_1920s';
    }
  }
  
  // Standard mappings
  const locationMappings: Record<string, string> = {
    'rome': 'rome_ancient',
    'paris': 'paris_medieval', 
    'florence': 'florence_renaissance',
    'london': 'london_industrial',
    'new york': 'new_york_1920s'
  };
  
  const periodMappings: Record<string, Record<string, string>> = {
    'rome': { 'ancient': 'rome_ancient' },
    'paris': { 'medieval': 'paris_medieval' },
    'florence': { 'renaissance': 'florence_renaissance' },
    'london': { 'industrial': 'london_industrial' },
    'new york': { 'custom': 'new_york_1920s' }
  };
  
  // Check for specific period mappings first
  for (const [loc, periods] of Object.entries(periodMappings)) {
    if (normalizedLocation.includes(loc) && periods[period]) {
      return periods[period];
    }
  }
  
  // Fall back to location mappings
  for (const [loc, key] of Object.entries(locationMappings)) {
    if (normalizedLocation.includes(loc)) {
      return key;
    }
  }
  
  return '';
}

export function isFixedPlaceAvailable(location: string, timePeriod: string, customYear?: string): boolean {
  const key = getFixedPlaceKey(location, timePeriod, customYear);
  return key !== '' && FIXED_PLACES_DATA[key] !== undefined;
}