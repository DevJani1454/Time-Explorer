import { FIXED_PLACES_DATA, getFixedPlaceKey, isFixedPlaceAvailable, type FixedPlaceData } from '../data/fixedPlaces';

interface HistoricalContent {
  narrative: string;
  culturalInfo: string;
  architecturalDetails: string;
  lifestyleDescription: string;
  keyFacts: string[];
  notableFigures: Array<{
    name: string;
    role: string;
    years: string;
  }>;
  historicalEvents: Array<{
    event: string;
    year: string;
    significance: string;
  }>;
  images: {
    historicalVisualization: string;
    modernComparison: string;
    culturalArtifacts: string;
  };
  audioNarration?: string;
  locationData?: any;
}

class FixedPlacesService {
  constructor() {
    console.log('🏛️ Fixed Places Service initialized');
    console.log(`📊 Available locations: ${Object.keys(FIXED_PLACES_DATA).length}`);
    console.log('🎯 Mode: Fixed data with instant results');
  }

  isLocationAvailable(location: string, timePeriod: string, customYear?: string): boolean {
    return isFixedPlaceAvailable(location, timePeriod, customYear);
  }

  getAvailableLocations(): string[] {
    return [
      'Rome (Ancient Times)',
      'Paris (Medieval Period)', 
      'Florence (Renaissance)',
      'London (Industrial Revolution)',
      'New York (1920s)'
    ];
  }

  async generateHistoricalContent(
    location: string, 
    timePeriod: string, 
    contentType: string = 'comprehensive',
    customYear?: string
  ): Promise<HistoricalContent> {
    console.log(`🏛️ Generating content for ${location} during ${timePeriod}...`);
    console.log(`🎯 Content focus: ${contentType}`);
    console.log(`🔧 Mode: Fixed data (instant results)`);

    const key = getFixedPlaceKey(location, timePeriod, customYear);
    const data = FIXED_PLACES_DATA[key];

    if (!data) {
      throw new Error(`No data available for ${location} during ${timePeriod}`);
    }

    // Simulate some processing time for realism
    await new Promise(resolve => setTimeout(resolve, 500));

    console.log('✅ Successfully retrieved fixed place data!');

    return {
      narrative: data.narrative,
      culturalInfo: data.culturalInfo,
      architecturalDetails: data.architecturalDetails,
      lifestyleDescription: data.lifestyleDescription,
      keyFacts: data.keyFacts,
      notableFigures: data.notableFigures,
      historicalEvents: data.historicalEvents,
      images: data.images,
      locationData: this.getMockLocationData(location)
    };
  }

  private getMockLocationData(location: string) {
    const coordinates: Record<string, { lat: number; lng: number }> = {
      'rome': { lat: 41.9028, lng: 12.4964 },
      'paris': { lat: 48.8566, lng: 2.3522 },
      'florence': { lat: 43.7696, lng: 11.2558 },
      'london': { lat: 51.5074, lng: -0.1278 },
      'new york': { lat: 40.7128, lng: -74.0060 }
    };

    const normalizedLocation = location.toLowerCase().trim();
    const coords = coordinates[normalizedLocation] || { lat: 0, lng: 0 };

    return {
      coordinates: coords,
      formattedAddress: location,
      placeId: `fixed_${normalizedLocation}`,
      types: ['locality', 'political']
    };
  }
}

export default FixedPlacesService;