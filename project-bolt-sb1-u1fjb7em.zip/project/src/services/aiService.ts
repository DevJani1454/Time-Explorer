import OpenAI from 'openai';

interface HistoricalContent {
  narrative: string;
  culturalInfo: string;
  architecturalDetails: string;
  lifestyleDescription: string;
  keyFacts: string[];
  notableFigures: Array<{
    name: string;
    role: string;
    years: string;
  }>;
  historicalEvents: Array<{
    event: string;
    year: string;
    significance: string;
  }>;
  images: {
    historicalVisualization: string;
    modernComparison: string;
    culturalArtifacts: string;
  };
  audioNarration?: string;
  locationData?: any;
}

interface ElevenLabsResponse {
  audio_base64?: string;
  message?: string;
}

class AIService {
  private openai: OpenAI;
  private apiKey: string;
  private elevenlabsKey: string;
  private mapsKey: string;

  constructor() {
    this.apiKey = import.meta.env.VITE_OPENAI_API_KEY || '';
    this.elevenlabsKey = import.meta.env.VITE_ELEVENLABS_API_KEY || '';
    this.mapsKey = import.meta.env.VITE_GOOGLE_MAPS_API_KEY || '';
    
    if (!this.apiKey) {
      throw new Error('OpenAI API key is required');
    }

    this.openai = new OpenAI({
      apiKey: this.apiKey,
      dangerouslyAllowBrowser: true
    });

    console.log('🚀 AI Service initialized with real API keys!');
    console.log('📊 Service Status:');
    console.log('  OpenAI: Connected ✅');
    console.log('  ElevenLabs:', this.elevenlabsKey ? 'Connected ✅' : 'Missing ⚠️');
    console.log('  Google Maps:', this.mapsKey ? 'Connected ✅' : 'Missing ⚠️');
  }

  async generateHistoricalContent(
    location: string, 
    timePeriod: string, 
    contentType: string = 'comprehensive'
  ): Promise<HistoricalContent> {
    console.log(`🏛️ Generating AI content for ${location} during ${timePeriod}...`);
    console.log(`🎯 Content focus: ${contentType}`);
    console.log(`🔧 Mode: LIVE AI with real APIs`);

    try {
      // Generate all content in parallel for speed
      const [
        narrative,
        culturalInfo,
        architecturalDetails,
        lifestyleDescription,
        additionalData,
        images,
        audioNarration,
        locationData
      ] = await Promise.all([
        this.generateNarrative(location, timePeriod, contentType),
        this.generateCulturalInfo(location, timePeriod),
        this.generateArchitecturalDetails(location, timePeriod),
        this.generateLifestyleDescription(location, timePeriod),
        this.generateAdditionalData(location, timePeriod),
        this.generateImages(location, timePeriod),
        this.generateAudioNarration(location, timePeriod),
        this.getLocationData(location)
      ]);

      console.log('✅ Successfully generated all AI content!');

      return {
        narrative,
        culturalInfo,
        architecturalDetails,
        lifestyleDescription,
        keyFacts: additionalData.keyFacts,
        notableFigures: additionalData.notableFigures,
        historicalEvents: additionalData.historicalEvents,
        images,
        audioNarration,
        locationData
      };

    } catch (error) {
      console.error('❌ Error generating AI content:', error);
      // Fallback to enhanced mock content if API fails
      return this.generateFallbackContent(location, timePeriod, contentType);
    }
  }

  private async generateNarrative(location: string, timePeriod: string, contentType: string): Promise<string> {
    const prompt = `Write a comprehensive, engaging historical narrative about ${location} during ${timePeriod}. 
    Focus on ${contentType}. Include:
    - What the area looked like and felt like during this time
    - Major cultural and social aspects
    - Important historical context
    - Daily life of people living there
    - Significant events or changes happening
    - Vivid descriptions that bring the past to life
    
    Write in an immersive, storytelling style that makes readers feel like they're experiencing history firsthand. 
    Aim for 800-1000 words with rich detail and historical accuracy.`;

    const response = await this.openai.chat.completions.create({
      model: "gpt-4o",
      messages: [{ role: "user", content: prompt }],
      max_tokens: 1500,
      temperature: 0.7
    });

    return response.choices[0].message.content || 'Content generation failed';
  }

  private async generateCulturalInfo(location: string, timePeriod: string): Promise<string> {
    const prompt = `Provide comprehensive cultural information about ${location} during ${timePeriod}. Include:
    - Religious practices and beliefs
    - Art, music, and literature
    - Social customs and traditions
    - Food and cuisine
    - Clothing and fashion
    - Festivals and celebrations
    - Social hierarchy and class structure
    - Marriage and family customs
    - Educational practices
    
    Be specific, historically accurate, and engaging. Aim for 600-700 words.`;

    const response = await this.openai.chat.completions.create({
      model: "gpt-4o",
      messages: [{ role: "user", content: prompt }],
      max_tokens: 1000,
      temperature: 0.7
    });

    return response.choices[0].message.content || 'Cultural information generation failed';
  }

  private async generateArchitecturalDetails(location: string, timePeriod: string): Promise<string> {
    const prompt = `Describe the architecture and buildings of ${location} during ${timePeriod}. Include:
    - Typical building styles and materials
    - Notable structures or monuments
    - Urban planning and city layout
    - Construction techniques and innovations
    - Architectural influences from other cultures
    - How buildings reflected the culture and society
    - Specific examples of famous buildings from that era
    - Interior design and decoration
    
    Be detailed, historically accurate, and paint a vivid picture. Aim for 600-700 words.`;

    const response = await this.openai.chat.completions.create({
      model: "gpt-4o",
      messages: [{ role: "user", content: prompt }],
      max_tokens: 1000,
      temperature: 0.7
    });

    return response.choices[0].message.content || 'Architectural details generation failed';
  }

  private async generateLifestyleDescription(location: string, timePeriod: string): Promise<string> {
    const prompt = `Describe daily life and lifestyle in ${location} during ${timePeriod}. Include:
    - How people lived day-to-day
    - Work and occupations
    - Family life and social structure
    - Education and learning
    - Entertainment and leisure activities
    - Transportation and communication
    - Economic activities and trade
    - Health and medicine
    - Gender roles and expectations
    - Seasonal variations in lifestyle
    
    Paint a vivid picture of what life was really like. Aim for 600-700 words.`;

    const response = await this.openai.chat.completions.create({
      model: "gpt-4o",
      messages: [{ role: "user", content: prompt }],
      max_tokens: 1000,
      temperature: 0.7
    });

    return response.choices[0].message.content || 'Lifestyle description generation failed';
  }

  private async generateAdditionalData(location: string, timePeriod: string): Promise<{
    keyFacts: string[];
    notableFigures: Array<{ name: string; role: string; years: string }>;
    historicalEvents: Array<{ event: string; year: string; significance: string }>;
  }> {
    const prompt = `Provide structured information about ${location} during ${timePeriod} in JSON format:
    {
      "keyFacts": ["fact1", "fact2", "fact3", "fact4", "fact5", "fact6", "fact7"],
      "notableFigures": [
        {"name": "Person Name", "role": "Their role/significance", "years": "Active years"},
        {"name": "Person Name", "role": "Their role/significance", "years": "Active years"},
        {"name": "Person Name", "role": "Their role/significance", "years": "Active years"},
        {"name": "Person Name", "role": "Their role/significance", "years": "Active years"}
      ],
      "historicalEvents": [
        {"event": "Event name", "year": "Year", "significance": "Why it was important"},
        {"event": "Event name", "year": "Year", "significance": "Why it was important"},
        {"event": "Event name", "year": "Year", "significance": "Why it was important"},
        {"event": "Event name", "year": "Year", "significance": "Why it was important"}
      ]
    }
    
    Provide accurate historical information. Return ONLY valid JSON, no other text.`;

    try {
      const response = await this.openai.chat.completions.create({
        model: "gpt-4o",
        messages: [{ role: "user", content: prompt }],
        max_tokens: 1200,
        temperature: 0.7
      });

      const content = response.choices[0].message.content || '{}';
      return JSON.parse(content);
    } catch (error) {
      console.error('Error parsing additional data:', error);
      return {
        keyFacts: ["Historical data is being compiled..."],
        notableFigures: [],
        historicalEvents: []
      };
    }
  }

  private async generateImages(location: string, timePeriod: string): Promise<{
    historicalVisualization: string;
    modernComparison: string;
    culturalArtifacts: string;
  }> {
    try {
      console.log('🎨 Generating DALL-E 3 images...');

      // Generate historical visualization
      const historicalPrompt = `Create a detailed, historically accurate illustration of ${location} during ${timePeriod}. Show the architecture, people in period-appropriate clothing, daily activities, and the overall atmosphere of the time. Include accurate historical details like building styles, clothing, transportation, and street scenes. Artistic, detailed, historically accurate style.`;

      // Generate modern comparison
      const modernPrompt = `Create a modern, realistic photograph of ${location} today. Show contemporary architecture, modern streets, current urban life, and present-day atmosphere. High-quality, realistic, daytime photography style.`;

      // Generate cultural artifacts
      const artifactsPrompt = `Create an educational illustration showing cultural artifacts and objects from ${location} during ${timePeriod}. Include tools, art pieces, clothing, pottery, weapons, jewelry, or other items that were typical of the time and place. Arrange them in a museum-style display. Educational, detailed, high-quality illustration style.`;

      const [historicalImage, modernImage, artifactsImage] = await Promise.all([
        this.generateSingleImage(historicalPrompt),
        this.generateSingleImage(modernPrompt),
        this.generateSingleImage(artifactsPrompt)
      ]);

      return {
        historicalVisualization: historicalImage,
        modernComparison: modernImage,
        culturalArtifacts: artifactsImage
      };

    } catch (error) {
      console.error('Error generating images:', error);
      return this.getFallbackImages();
    }
  }

  private async generateSingleImage(prompt: string): Promise<string> {
    try {
      const response = await this.openai.images.generate({
        model: "dall-e-3",
        prompt: prompt,
        size: "1024x1024",
        quality: "hd",
        n: 1,
      });

      return response.data[0].url || 'Image generation failed';
    } catch (error) {
      console.error('Error generating single image:', error);
      throw error;
    }
  }

  private async generateAudioNarration(location: string, timePeriod: string): Promise<string | undefined> {
    if (!this.elevenlabsKey) {
      console.log('⚠️ ElevenLabs API key not available, skipping audio generation');
      return undefined;
    }

    try {
      console.log('🎵 Generating ElevenLabs audio narration...');

      const narrativeText = `Welcome to ${location} during ${timePeriod}. Step back in time and experience the rich history, vibrant culture, and daily life of this remarkable place. Through the power of artificial intelligence, we bring the past to life with authentic details and immersive storytelling.`;

      const response = await fetch('https://api.elevenlabs.io/v1/text-to-speech/21m00Tcm4TlvDq8ikWAM', {
        method: 'POST',
        headers: {
          'Accept': 'audio/mpeg',
          'Content-Type': 'application/json',
          'xi-api-key': this.elevenlabsKey
        },
        body: JSON.stringify({
          text: narrativeText,
          model_id: 'eleven_monolingual_v1',
          voice_settings: {
            stability: 0.5,
            similarity_boost: 0.5
          }
        })
      });

      if (response.ok) {
        const audioBlob = await response.blob();
        const audioUrl = URL.createObjectURL(audioBlob);
        console.log('✅ Audio narration generated successfully');
        return audioUrl;
      } else {
        console.error('ElevenLabs API error:', response.status, response.statusText);
        return undefined;
      }

    } catch (error) {
      console.error('Error generating audio narration:', error);
      return undefined;
    }
  }

  private async getLocationData(location: string): Promise<any> {
    if (!this.mapsKey) {
      console.log('⚠️ Google Maps API key not available, using fallback location data');
      return this.getFallbackLocationData(location);
    }

    try {
      console.log('🗺️ Fetching Google Maps location data...');

      const response = await fetch(
        `https://maps.googleapis.com/maps/api/geocode/json?address=${encodeURIComponent(location)}&key=${this.mapsKey}`
      );

      if (response.ok) {
        const data = await response.json();
        if (data.results && data.results.length > 0) {
          const result = data.results[0];
          console.log('✅ Location data retrieved successfully');
          return {
            coordinates: result.geometry.location,
            formattedAddress: result.formatted_address,
            placeId: result.place_id,
            types: result.types
          };
        }
      }

      return this.getFallbackLocationData(location);

    } catch (error) {
      console.error('Error fetching location data:', error);
      return this.getFallbackLocationData(location);
    }
  }

  private getFallbackLocationData(location: string) {
    return {
      coordinates: { lat: 0, lng: 0 },
      formattedAddress: location,
      placeId: 'unknown',
      types: ['locality']
    };
  }

  private getFallbackImages() {
    return {
      historicalVisualization: 'https://images.pexels.com/photos/1670187/pexels-photo-1670187.jpeg?auto=compress&cs=tinysrgb&w=800',
      modernComparison: 'https://images.pexels.com/photos/466685/pexels-photo-466685.jpeg?auto=compress&cs=tinysrgb&w=800',
      culturalArtifacts: 'https://images.pexels.com/photos/1007025/pexels-photo-1007025.jpeg?auto=compress&cs=tinysrgb&w=800'
    };
  }

  private generateFallbackContent(location: string, timePeriod: string, contentType: string): HistoricalContent {
    return {
      narrative: `During ${timePeriod}, ${location} was a vibrant center of human activity and cultural development. The streets bustled with merchants, artisans, and citizens going about their daily lives in ways both familiar and foreign to our modern eyes. This was a time of both continuity and change, where ancient traditions met new innovations, creating a unique cultural landscape that would influence generations to come.`,
      culturalInfo: `The cultural life of ${location} during ${timePeriod} was rich and multifaceted. Religious practices played a central role in daily life, with ceremonies and festivals marking important seasonal and life transitions. Art and music flourished, often serving both decorative and spiritual purposes.`,
      architecturalDetails: `The architectural landscape of ${location} during ${timePeriod} showcased the engineering capabilities and aesthetic sensibilities of the era. Buildings were constructed using locally available materials with techniques that had been perfected over generations.`,
      lifestyleDescription: `Daily life in ${location} during ${timePeriod} followed rhythms dictated by the sun, seasons, and social obligations. Most people rose early and worked until sunset, with activities varying greatly depending on occupation, social class, and gender.`,
      keyFacts: [
        `${location} was a major center during ${timePeriod}`,
        'Population was smaller than today',
        'Buildings used local materials',
        'Life revolved around seasonal changes',
        'Social hierarchy was important'
      ],
      notableFigures: [
        { name: 'Historical Leader', role: 'Influential ruler', years: 'Active during period' },
        { name: 'Cultural Figure', role: 'Artist or writer', years: 'Contributed to culture' }
      ],
      historicalEvents: [
        { event: 'Major Event', year: 'During period', significance: 'Shaped the region' },
        { event: 'Cultural Milestone', year: 'Another year', significance: 'Influenced society' }
      ],
      images: this.getFallbackImages(),
      locationData: this.getFallbackLocationData(location)
    };
  }
}

export default AIService;