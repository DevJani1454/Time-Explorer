// OpenAI Service for Historical Content Generation
// This would integrate with OpenAI API when API key is provided

interface HistoricalContent {
  narrative: string;
  culturalInfo: string;
  architecturalDetails: string;
  lifestyleDescription: string;
  keyFacts: string[];
  notableFigures: Array<{
    name: string;
    role: string;
    years: string;
  }>;
  historicalEvents: Array<{
    event: string;
    year: string;
    significance: string;
  }>;
}

interface ImageUrls {
  historicalImageUrl: string;
  modernComparisonUrl: string;
  culturalArtifactUrl: string;
}

class OpenAIService {
  private apiKey: string;
  private baseUrl: string = 'https://api.openai.com/v1';

  constructor(apiKey?: string) {
    this.apiKey = apiKey || process.env.REACT_APP_OPENAI_API_KEY || '';
  }

  async generateHistoricalContent(
    location: string, 
    timePeriod: string, 
    contentType: string = 'comprehensive'
  ): Promise<HistoricalContent> {
    if (!this.apiKey) {
      return this.getMockContent(location, timePeriod);
    }

    try {
      // Generate comprehensive historical content
      const narrative = await this.generateNarrative(location, timePeriod, contentType);
      const culturalInfo = await this.generateCulturalInfo(location, timePeriod);
      const architecturalDetails = await this.generateArchitecturalDetails(location, timePeriod);
      const lifestyleDescription = await this.generateLifestyleDescription(location, timePeriod);
      const additionalData = await this.generateAdditionalData(location, timePeriod);

      return {
        narrative,
        culturalInfo,
        architecturalDetails,
        lifestyleDescription,
        ...additionalData
      };
    } catch (error) {
      console.error('Error generating content:', error);
      return this.getMockContent(location, timePeriod);
    }
  }

  async generateImages(location: string, timePeriod: string): Promise<ImageUrls> {
    if (!this.apiKey) {
      return this.getMockImages();
    }

    try {
      // Generate historical visualization
      const historicalImageUrl = await this.generateHistoricalImage(location, timePeriod);
      
      // Generate modern comparison
      const modernComparisonUrl = await this.generateModernImage(location);
      
      // Generate cultural artifacts
      const culturalArtifactUrl = await this.generateArtifactImage(location, timePeriod);

      return {
        historicalImageUrl,
        modernComparisonUrl,
        culturalArtifactUrl
      };
    } catch (error) {
      console.error('Error generating images:', error);
      return this.getMockImages();
    }
  }

  private async generateNarrative(location: string, timePeriod: string, contentType: string): Promise<string> {
    const prompt = `Write a comprehensive historical narrative about ${location} during ${timePeriod}. 
    Focus on ${contentType}. Include:
    - What the area looked like and felt like during this time
    - Major cultural and social aspects
    - Important historical context
    - Daily life of people living there
    - Significant events or changes happening
    
    Write in an engaging, informative style that brings the past to life. Limit to 500 words.`;

    return await this.callOpenAI(prompt);
  }

  private async generateCulturalInfo(location: string, timePeriod: string): Promise<string> {
    const prompt = `Provide detailed cultural information about ${location} during ${timePeriod}. Include:
    - Religious practices and beliefs
    - Art, music, and literature
    - Social customs and traditions
    - Food and cuisine
    - Clothing and fashion
    - Festivals and celebrations
    
    Be specific and historically accurate. Limit to 400 words.`;

    return await this.callOpenAI(prompt);
  }

  private async generateArchitecturalDetails(location: string, timePeriod: string): Promise<string> {
    const prompt = `Describe the architecture and buildings of ${location} during ${timePeriod}. Include:
    - Typical building styles and materials
    - Notable structures or monuments
    - Urban planning and city layout
    - Construction techniques
    - Architectural influences
    - How buildings reflected the culture and society
    
    Be detailed and historically accurate. Limit to 400 words.`;

    return await this.callOpenAI(prompt);
  }

  private async generateLifestyleDescription(location: string, timePeriod: string): Promise<string> {
    const prompt = `Describe daily life and lifestyle in ${location} during ${timePeriod}. Include:
    - How people lived day-to-day
    - Work and occupations
    - Family life and social structure
    - Education and learning
    - Entertainment and leisure
    - Transportation and communication
    - Economic activities
    
    Paint a vivid picture of what life was really like. Limit to 400 words.`;

    return await this.callOpenAI(prompt);
  }

  private async generateAdditionalData(location: string, timePeriod: string): Promise<{
    keyFacts: string[];
    notableFigures: Array<{ name: string; role: string; years: string }>;
    historicalEvents: Array<{ event: string; year: string; significance: string }>;
  }> {
    const prompt = `Provide structured information about ${location} during ${timePeriod} in JSON format:
    {
      "keyFacts": ["fact1", "fact2", "fact3", "fact4", "fact5"],
      "notableFigures": [
        {"name": "Person Name", "role": "Their role/significance", "years": "Active years"},
        {"name": "Person Name", "role": "Their role/significance", "years": "Active years"}
      ],
      "historicalEvents": [
        {"event": "Event name", "year": "Year", "significance": "Why it was important"},
        {"event": "Event name", "year": "Year", "significance": "Why it was important"}
      ]
    }
    
    Provide accurate historical information.`;

    try {
      const response = await this.callOpenAI(prompt);
      return JSON.parse(response);
    } catch (error) {
      return {
        keyFacts: ["Historical data is being compiled..."],
        notableFigures: [],
        historicalEvents: []
      };
    }
  }

  private async generateHistoricalImage(location: string, timePeriod: string): Promise<string> {
    // This would use OpenAI's image generation API
    // For now, return a placeholder
    return 'https://images.pexels.com/photos/1670187/pexels-photo-1670187.jpeg?auto=compress&cs=tinysrgb&w=800';
  }

  private async generateModernImage(location: string): Promise<string> {
    // This would use OpenAI's image generation API
    // For now, return a placeholder
    return 'https://images.pexels.com/photos/466685/pexels-photo-466685.jpeg?auto=compress&cs=tinysrgb&w=800';
  }

  private async generateArtifactImage(location: string, timePeriod: string): Promise<string> {
    // This would use OpenAI's image generation API
    // For now, return a placeholder
    return 'https://images.pexels.com/photos/1007025/pexels-photo-1007025.jpeg?auto=compress&cs=tinysrgb&w=800';
  }

  private async callOpenAI(prompt: string): Promise<string> {
    const response = await fetch(`${this.baseUrl}/chat/completions`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${this.apiKey}`
      },
      body: JSON.stringify({
        model: 'gpt-4',
        messages: [{ role: 'user', content: prompt }],
        max_tokens: 1000,
        temperature: 0.7
      })
    });

    if (!response.ok) {
      throw new Error(`OpenAI API error: ${response.statusText}`);
    }

    const data = await response.json();
    return data.choices[0].message.content;
  }

  private getMockContent(location: string, timePeriod: string): HistoricalContent {
    return {
      narrative: `During ${timePeriod}, ${location} was a vibrant center of human activity and cultural development. The streets bustled with merchants, artisans, and citizens going about their daily lives in ways both familiar and foreign to our modern eyes. 

The architecture of this era reflected the technological capabilities and aesthetic values of the time, with buildings constructed using locally available materials and techniques passed down through generations. The urban layout followed patterns that balanced practical needs with cultural and religious considerations.

Social life was deeply intertwined with the rhythms of the seasons and the demands of survival and prosperity. Communities were tightly knit, with extended families and neighborhood networks providing support and structure. Trade and commerce flourished, connecting ${location} to distant lands and bringing new ideas, goods, and influences.

This was a time of both continuity and change, where ancient traditions met new innovations, creating a unique cultural landscape that would influence generations to come.`,

      culturalInfo: `The cultural life of ${location} during ${timePeriod} was rich and multifaceted. Religious practices played a central role in daily life, with ceremonies and festivals marking important seasonal and life transitions. Art and music flourished, often serving both decorative and spiritual purposes.

Social customs were deeply rooted in tradition, governing everything from marriage and family relationships to business dealings and community governance. Clothing and fashion reflected both practical needs and social status, with different classes and professions distinguished by their attire.

Food culture was closely tied to local agriculture and trade networks, with cuisine featuring seasonal ingredients and preparation methods that had been refined over centuries. Festivals and celebrations brought communities together, reinforcing social bonds and cultural identity.`,

      architecturalDetails: `The architectural landscape of ${location} during ${timePeriod} showcased the engineering capabilities and aesthetic sensibilities of the era. Buildings were constructed using locally available materials such as stone, wood, clay, and metal, with techniques that had been perfected over generations.

Urban planning reflected both practical considerations and cultural values. Streets were laid out to facilitate trade and movement while also serving defensive purposes. Public spaces like markets, temples, and gathering areas were positioned to serve as focal points for community life.

Religious and civic buildings represented the pinnacle of architectural achievement, featuring innovative construction techniques, decorative elements, and symbolic designs that conveyed important cultural and spiritual messages.`,

      lifestyleDescription: `Daily life in ${location} during ${timePeriod} followed rhythms dictated by the sun, seasons, and social obligations. Most people rose early and worked until sunset, with activities varying greatly depending on occupation, social class, and gender.

Family life was central to social organization, with multiple generations often living together in extended household units. Children learned essential skills through observation and participation in adult activities, with formal education available primarily to the wealthy.

Work and economic activities were diverse, ranging from agriculture and crafts to trade and administration. Entertainment and leisure activities provided relief from daily labors, with music, storytelling, games, and festivals offering opportunities for social interaction.`,

      keyFacts: [
        `${location} was a major center of trade and cultural exchange during ${timePeriod}`,
        'The population was estimated to be significantly smaller than today',
        'Most buildings were constructed using local materials and traditional techniques',
        'Daily life revolved around agricultural cycles and seasonal changes',
        'Social hierarchy played a major role in determining life opportunities'
      ],

      notableFigures: [
        {
          name: 'Historical Leader',
          role: 'Influential ruler or administrator',
          years: 'Active during this period'
        },
        {
          name: 'Cultural Figure',
          role: 'Artist, writer, or religious leader',
          years: 'Contributed to cultural development'
        }
      ],

      historicalEvents: [
        {
          event: 'Major Historical Event',
          year: 'Specific year during period',
          significance: 'Shaped the development of the region'
        },
        {
          event: 'Cultural Milestone',
          year: 'Another significant year',
          significance: 'Influenced art, religion, or society'
        }
      ]
    };
  }

  private getMockImages(): ImageUrls {
    return {
      historicalImageUrl: 'https://images.pexels.com/photos/1670187/pexels-photo-1670187.jpeg?auto=compress&cs=tinysrgb&w=800',
      modernComparisonUrl: 'https://images.pexels.com/photos/466685/pexels-photo-466685.jpeg?auto=compress&cs=tinysrgb&w=800',
      culturalArtifactUrl: 'https://images.pexels.com/photos/1007025/pexels-photo-1007025.jpeg?auto=compress&cs=tinysrgb&w=800'
    };
  }
}

export default OpenAIService;