import React from 'react';
import { ExternalLink, Heart } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="fixed bottom-0 left-0 right-0 glass-effect border-t border-gray-700">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
        <div className="flex flex-col sm:flex-row justify-between items-center space-y-2 sm:space-y-0">
          <div className="flex items-center space-x-2 text-sm text-gray-400">
            <span>Built with</span>
            <Heart className="w-4 h-4 text-red-500 animate-pulse" />
            <span>using</span>
            <a
              href="https://bolt.new"
              target="_blank"
              rel="noopener noreferrer"
              className="text-gold hover:text-yellow-300 transition-colors inline-flex items-center space-x-1"
            >
              <span className="font-mono">Bolt.new</span>
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>
          
          <div className="text-xs text-gray-500 font-mono">
            © 2025 Time Explorer - Journey Through History
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;