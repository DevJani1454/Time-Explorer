import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navigation from './components/Navigation';
import HomePage from './pages/HomePage';
import ExplorationPage from './pages/ExplorationPage';
import ResultsPage from './pages/ResultsPage';
import AboutPage from './pages/AboutPage';
import CommunityPage from './pages/CommunityPage';
import Footer from './components/Footer';

function App() {
  return (
    <Router>
      <div className="min-h-screen cultural-gradient">
        <Navigation />
        <main className="pb-20">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/explore" element={<ExplorationPage />} />
            <Route path="/results" element={<ResultsPage />} />
            <Route path="/about" element={<AboutPage />} />
            <Route path="/community" element={<CommunityPage />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </Router>
  );
}

export default App;